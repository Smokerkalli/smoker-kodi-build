# -*- coding: utf-8 -*-
import json
import os
import sys

import xbmc
import xbmcgui
import xbmcvfs

PLUGIN_ID = 'plugin.video.smoker.livetv.favorites'
DATA_DIR = xbmcvfs.translatePath(f'special://profile/addon_data/{PLUGIN_ID}')
FAV_FILE = os.path.join(DATA_DIR, 'favorites.json')
CAT_FILE = os.path.join(DATA_DIR, 'categories.json')
DEFAULT_CATEGORIES = ['Live TV', 'Sport', 'Filme', 'Serien']


def ensure_dir():
    if not xbmcvfs.exists(DATA_DIR):
        xbmcvfs.mkdirs(DATA_DIR)


def load_json(path, fallback):
    ensure_dir()
    if not xbmcvfs.exists(path):
        return fallback
    try:
        with xbmcvfs.File(path) as fh:
            raw = fh.read()
        if not raw:
            return fallback
        return json.loads(raw)
    except Exception:
        return fallback


def save_json(path, data):
    ensure_dir()
    with xbmcvfs.File(path, 'w') as fh:
        fh.write(json.dumps(data, ensure_ascii=False, indent=2))


def load_items():
    data = load_json(FAV_FILE, [])
    return data if isinstance(data, list) else []


def save_items(items):
    save_json(FAV_FILE, items)


def load_categories():
    data = load_json(CAT_FILE, DEFAULT_CATEGORIES[:])
    if not isinstance(data, list):
        data = DEFAULT_CATEGORIES[:]
    cleaned = []
    for entry in data:
        text = str(entry).strip()
        if text and text not in cleaned:
            cleaned.append(text)
    for default in DEFAULT_CATEGORIES:
        if default not in cleaned:
            cleaned.append(default)
    return cleaned


def save_categories(categories):
    cleaned = []
    for entry in categories:
        text = str(entry).strip()
        if text and text not in cleaned:
            cleaned.append(text)
    save_json(CAT_FILE, cleaned)


def notify(message, icon=xbmcgui.NOTIFICATION_INFO):
    xbmcgui.Dialog().notification('Smoker Live TV Favoriten', message, icon, 3500)


def get_art(item, key):
    try:
        return item.getArt(key) or ''
    except Exception:
        return ''


def ensure_category(name):
    name = str(name or '').strip()
    if not name:
        return None
    categories = load_categories()
    if name not in categories:
        categories.append(name)
        save_categories(categories)
    return name


def prompt_new_category(default_name=''):
    keyboard = xbmc.Keyboard(default_name, 'Neue Kategorie eingeben')
    keyboard.doModal()
    if not keyboard.isConfirmed():
        return None
    name = keyboard.getText().strip()
    if not name:
        notify('Kategoriename darf nicht leer sein', xbmcgui.NOTIFICATION_WARNING)
        return None
    return ensure_category(name)


def choose_category():
    categories = load_categories()
    options = categories + ['[B]Neue Kategorie...[/B]']
    selected = xbmcgui.Dialog().select('Kategorie wählen', options, preselect=0)
    if selected < 0:
        return None
    if selected == len(categories):
        return prompt_new_category()
    return categories[selected]


def main():
    li = getattr(sys, 'listitem', None)
    if li is None:
        notify('Kein Eintrag ausgewählt', xbmcgui.NOTIFICATION_ERROR)
        return

    label = li.getLabel() or li.getLabel2() or 'Unbenannter Eintrag'
    target = li.getPath() or ''
    thumb = get_art(li, 'thumb') or get_art(li, 'icon')
    fanart = get_art(li, 'fanart')
    source_label = xbmc.getInfoLabel('Container.FolderName') or xbmc.getInfoLabel('Container.PluginName') or 'Kodi'
    item_type = 'playable' if (li.getProperty('IsPlayable') or '').lower() == 'true' else 'folder'

    if not target:
        notify('Dieser Eintrag hat keinen nutzbaren Pfad', xbmcgui.NOTIFICATION_ERROR)
        return

    category = choose_category()
    if not category:
        return

    items = load_items()
    for entry in items:
        if entry.get('target') == target:
            entry['category'] = category
            save_items(items)
            notify(f'Kategorie geändert: {category}')
            return

    items.append({
        'label': label,
        'target': target,
        'thumb': thumb,
        'fanart': fanart,
        'source_label': source_label,
        'item_type': item_type,
        'category': category,
    })
    save_items(items)
    notify(f'Hinzugefügt zu {category}: {label}')


if __name__ == '__main__':
    main()
