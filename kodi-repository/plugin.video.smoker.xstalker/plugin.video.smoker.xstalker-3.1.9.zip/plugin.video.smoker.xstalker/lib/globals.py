"""Module to initializes global setting for the plugin"""

from __future__ import absolute_import, division, unicode_literals
import os
import sys
from urllib.parse import urlencode, urlsplit
import dataclasses
import shutil
import xml.etree.ElementTree as ET
import xbmcaddon
import xbmcvfs
from .loggers import Logger


@dataclasses.dataclass
class PortalConfig:
    """Portal config"""
    mac_cookie: str = None
    portal_url: str = None
    category_filter: str = None
    device_id: str = None
    device_id_2: str = None
    signature: str = None
    serial_number: str = None
    portal_base_url: str = None
    server_address: str = None
    alternative_context_path: bool = False


@dataclasses.dataclass
class AddOnConfig:
    """Addon config"""
    url: str = None
    addon_id: str = None
    name: str = None
    handle: str = None
    addon_data_path: str = None
    max_page_limit: int = 2
    max_retries: int = 3
    token_path: str = None


class GlobalVariables:
    """Class initializes global settings used by the plugin"""

    def __init__(self):
        """Init class"""
        self.__addon = xbmcaddon.Addon()
        self.__is_addd_on_first_run = None
        self.addon_config = AddOnConfig()
        self.portal_config = PortalConfig()
        self.active_portal = 1
        self._loaded_portal_id = None  # Tracking für den Cache
        # Inhalts-Cache
        self.cache_vod_categories = {}
        self.cache_series_categories = {}
        self.cache_tv_genres = {}
        self.cache_epg = {}  # {portal_id: {channel_id: data}}
        self.cache_short_epg = {}  # {portal_id: {channel_id: data}}
        self._ensure_profile_migration()
        self._ensure_settings_compatibility()

    def _ensure_settings_compatibility(self):
        """Migrate legacy setting IDs that were accidentally shared by two fields."""
        try:
            if not self.__addon.getSetting('device_id_primary_2'):
                legacy_value = self.__addon.getSetting('device_id_2')
                if legacy_value:
                    self.__addon.setSetting('device_id_primary_2', legacy_value)
        except Exception as e:
            Logger.warn('Settings compatibility migration failed: {}'.format(str(e)))

    def _copy_tree(self, src, dst):
        if not os.path.exists(src):
            return
        if not os.path.exists(dst):
            os.makedirs(dst)
        for root, dirs, files in os.walk(src):
            rel = os.path.relpath(root, src)
            target_root = dst if rel == '.' else os.path.join(dst, rel)
            if not os.path.exists(target_root):
                os.makedirs(target_root)
            for d in dirs:
                td = os.path.join(target_root, d)
                if not os.path.exists(td):
                    os.makedirs(td)
            for name in files:
                sp = os.path.join(root, name)
                dp = os.path.join(target_root, name)
                if os.path.exists(dp):
                    continue
                try:
                    shutil.copy2(sp, dp)
                except Exception:
                    try:
                        with open(sp, 'rb') as sf, open(dp, 'wb') as df:
                            df.write(sf.read())
                    except Exception as e:
                        Logger.warn("Migration copy failed for {}: {}".format(sp, str(e)))

    def _import_old_settings(self, old_settings_path):
        if not os.path.exists(old_settings_path):
            return 0
        imported = 0
        try:
            tree = ET.parse(old_settings_path)
            root = tree.getroot()
            for elem in root.findall('.//setting'):
                key = elem.attrib.get('id')
                value = elem.attrib.get('value')
                if key is None:
                    continue
                if value is None:
                    value = elem.text or ''
                try:
                    current = self.__addon.getSetting(key)
                except Exception:
                    current = ''
                if current not in (None, ''):
                    continue
                try:
                    self.__addon.setSetting(key, value)
                    imported += 1
                except Exception as e:
                    Logger.warn("Setting migration failed for {}: {}".format(key, str(e)))
        except Exception as e:
            Logger.error("Old settings import failed: {}".format(str(e)))
        return imported

    def _ensure_profile_migration(self):
        try:
            addon_id = self.__addon.getAddonInfo('id')
            if addon_id != 'plugin.video.smoker.xstalker':
                return
            new_profile = xbmcvfs.translatePath(self.__addon.getAddonInfo('profile'))
            if not os.path.exists(new_profile):
                os.makedirs(new_profile)
            marker = os.path.join(new_profile, 'migration_from_svod.done')
            if os.path.exists(marker):
                return
            old_profile = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.svod/')
            if not os.path.exists(old_profile):
                return
            imported = self._import_old_settings(os.path.join(old_profile, 'settings.xml'))
            self._copy_tree(old_profile, new_profile)
            with open(marker, 'w', encoding='utf-8') as fh:
                fh.write('ok')
            Logger.info('Migrated addon profile from plugin.video.svod to plugin.video.smoker.xstalker (settings imported: {}).'.format(imported))
        except Exception as e:
            Logger.error('Profile migration failed: {}'.format(str(e)))


    def init_globals(self,portal_id=1):
        """Init global settings mit intelligentem Caching"""
        portal_id = int(portal_id)

        # Wenn das Portal bereits geladen ist, überspringen wir das erneute Einlesen
        if self._loaded_portal_id == portal_id:
            return

        # Wenn wir hier ankommen, findet ein Portalwechsel statt!

        self.active_portal = portal_id
        # Portal 1 nutzt keinen Suffix ('server_address')
        # Portal 2 bis 10 nutzen '_2', '_3', '_4', '_5'
        suffix = '' if self.active_portal == 1 else f'_{self.active_portal}'

        # Sicherer Zugriff auf sys.argv
        self.addon_config.url = sys.argv[0] if len(sys.argv) > 0 else ""

        Logger.debug("Switching to Portal {}. Loading settings...".format(self.active_portal))

        # Initialize addon info
        if self._loaded_portal_id is None:
            self.addon_config.addon_id = self.__addon.getAddonInfo('id')
            self.addon_config.name = self.__addon.getAddonInfo('name')
            self.addon_config.addon_data_path = self.__addon.getAddonInfo('path')
            token_path = xbmcvfs.translatePath(self.__addon.getAddonInfo('profile'))
            if not xbmcvfs.exists(token_path):
                xbmcvfs.mkdirs(token_path)
            self.addon_config.token_path = token_path
            #self.addon_config.handle = int(sys.argv[1])

            # Handle nur setzen, wenn wir im UI-Modus sind (argv vorhanden)
            if len(sys.argv) > 1:
                self.addon_config.handle = int(sys.argv[1])
            else:
                self.addon_config.handle = -1  # -1 signalisiert: Kein UI-Handle vorhanden

        # Init Portal settings
        self.portal_config.mac_cookie = 'mac=' + self.__addon.getSetting(f'mac_address{suffix}')
        self.portal_config.category_filter = self.__addon.getSetting(f'category_filter_portal{suffix}')
        primary_device_key = 'device_id_primary_2' if self.active_portal == 2 else f'device_id{suffix}'
        self.portal_config.device_id = self.__addon.getSetting(primary_device_key)
        if self.active_portal == 2 and not self.portal_config.device_id:
            self.portal_config.device_id = self.__addon.getSetting('device_id_2')
        self.portal_config.device_id_2 = self.__addon.getSetting(f'device_id_2{suffix}')
        self.portal_config.signature = self.__addon.getSetting(f'signature{suffix}')
        self.portal_config.serial_number = self.__addon.getSetting(f'serial_number{suffix}')
        self.portal_config.alternative_context_path = self.__addon.getSetting(
            f'alternative_context_path{suffix}') == 'true'

        self.portal_config.server_address = self.__addon.getSetting(f'server_address{suffix}')
        if self.portal_config.server_address:
            self.portal_config.portal_base_url = self.__get_portal_base_url()
            self.portal_config.portal_url = self.get_portal_url()

        # Per-Portal-Token-Cache aktiv: beim Portalwechsel nicht global leeren.

        # Jetzt markieren wir dieses Portal als geladen
        self._loaded_portal_id = portal_id

    def get_handle(self):
        """Get addon handle"""
        return self.addon_config.handle

    def get_custom_thumb_path(self, thumb_file_name):
        """Get thumb file path"""
        return os.path.join(self.addon_config.addon_data_path, 'resources', 'media', thumb_file_name)

    def get_plugin_url(self, params):
        """Get plugin url"""
        return '{}?{}'.format(self.addon_config.url, urlencode(params))

    def __get_portal_base_url(self):
        """Get portal base url"""
        split_url = urlsplit(self.portal_config.server_address)
        return split_url.scheme + '://' + split_url.netloc

    def __set_portal_addresses(self):
        """Set portal urls"""
        self.portal_config.server_address = self.__addon.getSetting('server_address')
        self.portal_config.portal_base_url = self.__get_portal_base_url()
        self.portal_config.portal_url = self.get_portal_url()

    def get_portal_url(self):
        """Get portal url"""
        context_path = '/portal.php' if self.portal_config.alternative_context_path else '/server/load.php'
        portal_url = self.portal_config.portal_base_url + '/stalker_portal' + context_path
        if self.portal_config.server_address.endswith('/c/'):
            portal_url = self.portal_config.server_address.replace('/c/', '') + context_path
        elif self.portal_config.server_address.endswith('/c'):
            portal_url = self.portal_config.server_address.replace('/c', '') + context_path
        return portal_url


G = GlobalVariables()
