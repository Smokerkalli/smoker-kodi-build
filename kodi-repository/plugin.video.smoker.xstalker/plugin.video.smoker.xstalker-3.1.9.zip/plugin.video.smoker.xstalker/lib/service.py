# -*- coding: utf-8 -*-
""" Background service code """

from __future__ import absolute_import, division, unicode_literals

from urllib.parse import urlsplit, parse_qsl, urlencode
import json
import os
import xbmc
from xbmc import Monitor, Player, getInfoLabel
import xbmcaddon
from .loggers import Logger
from .utils import get_int_value, get_next_info_and_send_signal
from .globals import G
from .api import Api
from .watchlist_database_handler import WatchlistDatabase


class StalkerService:
    def __init__(self):
        self.addon = xbmcaddon.Addon()

    def _get_portal_priority(self, portal_id):
        suffix = '' if int(portal_id) == 1 else '_{}'.format(int(portal_id))
        raw = (self.addon.getSetting('portal_priority{}'.format(suffix)) or '').strip()
        try:
            value = int(raw)
            return value if value > 0 else int(portal_id)
        except Exception:
            return int(portal_id)

    def _write_quickstart_cache(self, results):
        if self.addon.getSetting('quickstart_cache_enabled') != 'true':
            return
        try:
            profile_path = G.addon_config.token_path or xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
        except Exception:
            import xbmcvfs
            profile_path = xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
        try:
            import xbmcvfs
            if not xbmcvfs.exists(profile_path):
                xbmcvfs.mkdirs(profile_path)
            payload = {
                'preferred_portal': results[0]['portal_id'] if results else None,
                'reachable_portals': [item['portal_id'] for item in results],
                'results': results
            }
            cache_path = os.path.join(profile_path, 'quickstart_cache.json')
            fh = xbmcvfs.File(cache_path, 'w')
            fh.write(json.dumps(payload, ensure_ascii=False))
            fh.close()
            Logger.info('Quickstart cache updated: {}'.format(cache_path))
        except Exception as e:
            Logger.error('Quickstart cache write failed: {}'.format(str(e)))

    def run(self):
        Logger.info("Stalker Service started")

        # Warte kurz, bis Kodi stabil läuft (5 Sek)
        monitor = xbmc.Monitor()
        if monitor.waitForAbort(5):
            return

        # Auto-Wartung beim Start ausführen
        try:
            from .addon import StalkerAddon
            StalkerAddon._StalkerAddon__run_auto_maintenance(show_dialog=False)
        except Exception as e:
            Logger.error('Auto maintenance startup failed: {}'.format(str(e)))

        # Portal Precheck beim Start ausführen
        self.perform_portal_precheck()

        # EPG Preload beim Start ausführen
        self.perform_preload()

        # Der Service muss am Leben bleiben, damit Kodi ihn nicht neu startet
        # oder wir nutzen ihn nur als "One-Shot" beim Start.
        # Hier halten wir ihn aktiv, falls wir später Interval-Updates wollen:
        while not monitor.waitForAbort(3600):  # Prüfe alle Stunde
            pass

    def _is_portal_reachable(self, portal_id: int) -> bool:
        old_portal = G.active_portal
        try:
            G.init_globals(int(portal_id))
            from .auth import Auth
            Auth().get_token(refresh_token=False)
            try:
                Api._set_portal_error(int(portal_id), False)
            except Exception:
                pass
            return True
        except Exception as e:
            Logger.error(f"Portal {portal_id} unreachable (precheck): {str(e)}")
            try:
                Api._set_portal_error(int(portal_id), True, reason=f"precheck: {str(e)}")
            except Exception:
                pass
            return False
        finally:
            try:
                G.init_globals(old_portal)
            except Exception:
                pass

    def perform_portal_precheck(self):
        """
        Wird bei JEDEM Kodi-Start ausgeführt.
        Prüft alle konfigurierten Portale auf Erreichbarkeit und setzt portal_error entsprechend.
        """
        try:
            configured = []
            for i in range(1, 11):
                suffix = '' if i == 1 else f'_{i}'
                server = self.addon.getSetting(f'server_address{suffix}')
                mac = self.addon.getSetting(f'mac_address{suffix}')
                if server and mac and server.startswith('http'):
                    configured.append(i)
                elif not server and not mac:
                    self.addon.setSetting(f'portal_status_state{suffix}', 'empty')
                    self.addon.setSetting(f'portal_status_summary{suffix}', 'Nicht konfiguriert')
                    self.addon.setSetting(f'portal_error{suffix}', 'false')

            if not configured:
                Logger.info("Portal Precheck: no portals configured")
                return

            configured = sorted(configured, key=self._get_portal_priority)
            from .addon import StalkerAddon
            working = []
            quickstart_results = []
            for pid in configured:
                try:
                    result = StalkerAddon._StalkerAddon__run_portal_test(pid)
                    working.append(pid)
                    quickstart_results.append(result)
                    Logger.info(f"Portal {pid} startup check ok: {result.get('summary', '')}")
                except Exception as e:
                    suffix = '' if pid == 1 else f'_{pid}'
                    self.addon.setSetting(f'portal_status_state{suffix}', 'error')
                    self.addon.setSetting(f'portal_status_summary{suffix}', str(e) or 'Unbekannter Fehler')
                    self.addon.setSetting(f'portal_error{suffix}', 'true')
                    Logger.error(f"Portal {pid} startup check failed: {str(e)}")

            Logger.info(f"Portal Precheck: {len(working)}/{len(configured)} portals reachable: {working}")
            self._write_quickstart_cache(quickstart_results)

        except Exception as e:
            Logger.error(f"Portal precheck failed: {str(e)}")


    def perform_preload(self):
        try:
            mode_raw = self.addon.getSetting('epg_preload_mode')
            if not mode_raw or mode_raw == '0':
                Logger.info("EPG Preload is disabled in settings")
                return

            if self.addon.getSetting('epg_enabled') != 'true':
                Logger.info("EPG is disabled globally (epg_enabled=false)")
                return

            mode = int(mode_raw)

            original_user_portal = G.active_portal
            Logger.info(f"Starting EPG Preload for all portals (Mode: {mode})")

            # 1) Portale sammeln, die konfiguriert sind
            configured = []
            for i in range(1, 11):
                suffix = '' if i == 1 else f'_{i}'
                server = self.addon.getSetting(f'server_address{suffix}')
                if server and server.startswith('http'):
                    configured.append(i)

            # 2) Vorab prüfen, welche Portale antworten
            working = []
            for pid in configured:
                if self._is_portal_reachable(pid):
                    working.append(pid)

            Logger.info(f"EPG Precheck: {len(working)}/{len(configured)} portals reachable: {working}")

            # 3) Preload nur für funktionierende Portale
            for pid in working:
                Logger.debug(f"Preloading EPG for Portal {pid}...")
                Api.preload_epg_for_portal(pid, mode)
                xbmc.Monitor().waitForAbort(2)

            G.init_globals(original_user_portal)

        except Exception as e:
            Logger.error(f"Service preload failed: {str(e)}")


class BackgroundService(Monitor):
    """ Background service code """

    def __init__(self):
        Monitor.__init__(self)
        self._player = PlayerMonitor()

    def run(self):
        Logger.debug('Service started - Waiting for network...')

        # Kurz warten, bis das Netzwerk sicher da ist
        if self.waitForAbort(5): return

        # EPG Preload für alle konfigurierten Portale
        addon = G._GlobalVariables__addon  # Zugriff auf das Addon-Objekt
        try:
            # Nur fortfahren wenn EPG generell aktiviert ist
            if addon.getSetting('epg_enabled') == 'true':
                # Holen als String und konvertieren zu Int
                mode = int(addon.getSetting('epg_preload_mode') or 0)

                # Wir merken uns, welches Portal der User eigentlich gerade nutzt (meistens 1 beim Start)
                original_user_portal = G.active_portal

                if mode > 0:
                    for i in range(1, 11):
                        if self.abortRequested(): break

                        suffix = '' if i == 1 else f'_{i}'
                        server = addon.getSetting(f'server_address{suffix}')

                        if server and server.startswith('http'):
                            Logger.debug(f"Preloading EPG for Portal {i}...")
                            Api.preload_epg_for_portal(i, mode)
                            # Kleine Pause zwischen den Portalen, um den Server nicht zu stressen
                            self.waitForAbort(2)
                        G.init_globals(original_user_portal)
        except Exception as e:
            Logger.error(f"Error during background preload: {str(e)}")

        while not self.abortRequested():
            # Stop when abort requested
            if self.waitForAbort(10):
                break

        Logger.debug('Service stopped')


class PlayerMonitor(Player):
    """ A custom Player object to check subtitles """

    def __init__(self):
        """ Initialises a custom Player object """
        self.__listen = False
        self.__av_started = False
        self.__path = None
        self.__retry_count = 0
        Player.__init__(self)

    def __retry_playback(self, force_cmd=False):
        try:
            if not self.__path:
                return False
            params = dict(parse_qsl(urlsplit(self.__path).query))
            retry_count = int(params.get('auto_retry', self.__retry_count or 0))
            if retry_count >= 2:
                Logger.debug('Stalker Player: retry limit reached')
                return False
            from .auth import Auth
            try:
                Auth().clear_cache()
            except Exception:
                pass
            params['auto_retry'] = str(retry_count + 1)
            if force_cmd:
                params['use_cmd'] = '1'
            retry_url = '{}?{}'.format('plugin://{}/'.format(xbmcaddon.Addon().getAddonInfo('id')), urlencode(params))
            Logger.debug('Stalker Player: retrying playback {}'.format(retry_url))
            xbmc.executebuiltin('Dialog.Close(all, true)')
            xbmc.executebuiltin('PlayMedia({})'.format(retry_url))
            self.__retry_count = retry_count + 1
            return True
        except Exception as e:
            Logger.error('Stalker Player: retry failed {}'.format(str(e)))
            return False


def __persist_progress(self, completed=False):
    try:
        if not self.__path or not self.__path.startswith('plugin://{}/'.format(xbmcaddon.Addon().getAddonInfo('id'))):
            return
        params = dict(parse_qsl(urlsplit(self.__path).query))
        if params.get('action', '') != 'play':
            return
        series_no = int(params.get('series', 0) or 0)
        _type = 'series' if series_no > 0 else 'vod'
        video_id = params.get('video_id', '')
        portal_id = int(params.get('portal_id', G.active_portal or 1))
        if not video_id:
            return
        db = WatchlistDatabase()
        if completed:
            db.clear_progress(video_id, portal_id, _type, series_no)
            return
        try:
            current = int(self.getTime())
        except Exception:
            current = 0
        try:
            total = int(self.getTotalTime())
        except Exception:
            total = 0
        if current < 60:
            return
        if total > 0:
            remaining = max(0, total - current)
            if remaining <= 120 or current >= int(total * 0.92):
                db.clear_progress(video_id, portal_id, _type, series_no)
                return
        db.update_progress(video_id=video_id, portal_id=portal_id, _type=_type, title=params.get('title', ''), resume_seconds=current, total_seconds=total, series=series_no, season_no=int(params.get('season_no', 0) or 0), poster=params.get('poster_url', ''), cmd=params.get('cmd', ''), total_episodes=int(params.get('total_episodes', 0) or 0))
    except Exception as e:
        Logger.error('Stalker Player: persist progress failed {}'.format(str(e)))

    def onPlayBackStarted(self):  # pylint: disable=invalid-name
        """ Will be called when Kodi player starts """
        self.__path = getInfoLabel('Player.FilenameAndPath')
        if not self.__path.startswith('plugin://{}/'.format(xbmcaddon.Addon().getAddonInfo('id'))):
            self.__listen = False
            return
        self.__listen = True
        self.__av_started = False
        self.__retry_count = 0
        Logger.debug('Stalker Player: [onPlayBackStarted] called')

    def onAVStarted(self):  # pylint: disable=invalid-name
        """ Will be called when Kodi has a video or audiostream """
        if not self.__listen:
            return
        Logger.debug('Stalker Player: [onAVStarted] called')
        self.__av_started = True
        params = dict(parse_qsl(urlsplit(self.__path).query))
        resume_from = get_int_value(params, 'resume_from')
        if resume_from > 0:
            try:
                xbmc.sleep(750)
                self.seekTime(float(resume_from))
            except Exception:
                pass
        episode_no = get_int_value(params, 'series')
        total_episodes = get_int_value(params, 'total_episodes')
        if episode_no != 0 and episode_no < total_episodes:
            params.update({'series': episode_no + 1})
            next_episode_url = '{}?{}'.format('plugin://{}/'.format(xbmcaddon.Addon().getAddonInfo('id')), urlencode(params))
            get_next_info_and_send_signal(params, next_episode_url)

    def onPlayBackError(self):  # pylint: disable=invalid-name
        """ Will be called when playback stops due to an error. """
        if not self.__listen:
            return
        self.__av_started = False
        Logger.debug('Stalker Player: [onPlayBackError] called')
        if self.__retry_playback(force_cmd=False):
            return
        self.__listen = False

    def onPlayBackEnded(self):  # pylint: disable=invalid-name
        """ Will be called when [Kodi] stops playing a file """
        if not self.__listen:
            return
        Logger.debug('Stalker Player: [onPlayBackEnded] called')
        self.__persist_progress(completed=True)
        self.__listen = False
        self.__av_started = False

    def onPlayBackStopped(self):  # pylint: disable=invalid-name
        """ Will be called when [user] stops Kodi playing a file """
        if not self.__listen:
            return
        self.__persist_progress(completed=False)
        self.__listen = False
        if not self.__av_started:
            params = dict(parse_qsl(urlsplit(self.__path).query))
            if 'cmd' in params and params.get('use_cmd', '0') == '0':
                Logger.debug('Stalker Player: [onPlayBackStopped] playback failed? retrying with cmd {}'.format(self.__path + "&use_cmd=1"))
                if self.__retry_playback(force_cmd=True):
                    return
            elif self.__retry_playback(force_cmd=False):
                return
        self.__av_started = False
        Logger.debug('Stalker Player: [onPlayBackStopped] called')


def run():
    """ Run the BackgroundService """
    BackgroundService().run()
