
import os
import sqlite3
import xbmcvfs


class WatchlistDatabase:
    def __init__(self):
        import xbmcaddon
        db_dir = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        if not os.path.exists(db_dir):
            os.makedirs(db_dir)
        self.db_path = os.path.join(db_dir, 'watchlist.db')
        self._create_tables()

    def _connect(self):
        return sqlite3.connect(self.db_path)

    def _create_tables(self):
        with self._connect() as conn:
            conn.execute("CREATE TABLE IF NOT EXISTS watchlist (video_id TEXT, portal_id INTEGER, type TEXT, title TEXT, poster TEXT, cmd TEXT, description TEXT, added_ts INTEGER DEFAULT (strftime('%s','now')), PRIMARY KEY (video_id, portal_id, type))")
            conn.execute("CREATE TABLE IF NOT EXISTS progress (video_id TEXT, portal_id INTEGER, type TEXT, series INTEGER DEFAULT 0, season_no INTEGER DEFAULT 0, title TEXT, poster TEXT, cmd TEXT, total_episodes INTEGER DEFAULT 0, resume_seconds INTEGER DEFAULT 0, total_seconds INTEGER DEFAULT 0, updated_ts INTEGER DEFAULT (strftime('%s','now')), PRIMARY KEY (video_id, portal_id, type, series))")
            conn.execute("CREATE TABLE IF NOT EXISTS history (video_id TEXT, portal_id INTEGER, type TEXT, series INTEGER DEFAULT 0, season_no INTEGER DEFAULT 0, title TEXT, poster TEXT, cmd TEXT, last_position INTEGER DEFAULT 0, total_seconds INTEGER DEFAULT 0, updated_ts INTEGER DEFAULT (strftime('%s','now')), PRIMARY KEY (video_id, portal_id, type, series))")

    def add_watchlist_item(self, video_id, portal_id, _type, title, poster='', cmd='', description=''):
        with self._connect() as conn:
            conn.execute("INSERT OR REPLACE INTO watchlist (video_id, portal_id, type, title, poster, cmd, description, added_ts) VALUES (?, ?, ?, ?, ?, ?, ?, strftime('%s','now'))", (str(video_id), int(portal_id), str(_type), str(title or ''), str(poster or ''), str(cmd or ''), str(description or '')))

    def remove_watchlist_item(self, video_id, portal_id, _type):
        with self._connect() as conn:
            conn.execute('DELETE FROM watchlist WHERE video_id = ? AND portal_id = ? AND type = ?', (str(video_id), int(portal_id), str(_type)))

    def has_watchlist_item(self, video_id, portal_id, _type):
        with self._connect() as conn:
            cur = conn.execute('SELECT 1 FROM watchlist WHERE video_id = ? AND portal_id = ? AND type = ? LIMIT 1', (str(video_id), int(portal_id), str(_type)))
            return cur.fetchone() is not None

    def list_watchlist(self, _type):
        with self._connect() as conn:
            cur = conn.execute('SELECT video_id, portal_id, type, title, poster, cmd, description FROM watchlist WHERE type = ? ORDER BY added_ts DESC, title COLLATE NOCASE', (str(_type),))
            rows = cur.fetchall()
        return [{'video_id': r[0], 'portal_id': r[1], 'type': r[2], 'title': r[3], 'poster': r[4], 'cmd': r[5], 'description': r[6]} for r in rows]

    def update_progress(self, video_id, portal_id, _type, title, resume_seconds, total_seconds=0, series=0, season_no=0, poster='', cmd='', total_episodes=0):
        with self._connect() as conn:
            conn.execute("INSERT OR REPLACE INTO progress (video_id, portal_id, type, series, season_no, title, poster, cmd, total_episodes, resume_seconds, total_seconds, updated_ts) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, strftime('%s','now'))", (str(video_id), int(portal_id), str(_type), int(series or 0), int(season_no or 0), str(title or ''), str(poster or ''), str(cmd or ''), int(total_episodes or 0), int(resume_seconds or 0), int(total_seconds or 0)))

    def clear_progress(self, video_id, portal_id, _type, series=0):
        with self._connect() as conn:
            conn.execute('DELETE FROM progress WHERE video_id = ? AND portal_id = ? AND type = ? AND series = ?', (str(video_id), int(portal_id), str(_type), int(series or 0)))

    def clear_all_progress(self):
        with self._connect() as conn:
            conn.execute('DELETE FROM progress')

    def clear_watchlist(self):
        with self._connect() as conn:
            conn.execute('DELETE FROM watchlist')

    def list_progress(self, _type):
        with self._connect() as conn:
            cur = conn.execute('SELECT video_id, portal_id, type, series, season_no, title, poster, cmd, total_episodes, resume_seconds, total_seconds FROM progress WHERE type = ? AND resume_seconds > 0 ORDER BY updated_ts DESC', (str(_type),))
            rows = cur.fetchall()
        out = []
        for r in rows:
            resume = int(r[9] or 0)
            total = int(r[10] or 0)
            label = ''
            if total > 0:
                pct = max(1, min(99, int((resume / float(total)) * 100)))
                label = '{}%'.format(pct)
            elif resume > 0:
                label = '{} min'.format(max(1, int(resume / 60)))
            out.append({'video_id': r[0], 'portal_id': r[1], 'type': r[2], 'series': r[3], 'season_no': r[4], 'title': r[5], 'poster': r[6], 'cmd': r[7], 'total_episodes': r[8], 'resume_seconds': resume, 'total_seconds': total, 'progress_label': label})
        return out

    def add_history_item(self, video_id, portal_id, _type, title, poster='', cmd='', series=0, season_no=0, last_position=0, total_seconds=0):
        with self._connect() as conn:
            conn.execute("INSERT OR REPLACE INTO history (video_id, portal_id, type, series, season_no, title, poster, cmd, last_position, total_seconds, updated_ts) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, strftime('%s','now'))", (str(video_id), int(portal_id), str(_type), int(series or 0), int(season_no or 0), str(title or ''), str(poster or ''), str(cmd or ''), int(last_position or 0), int(total_seconds or 0)))

    def clear_history(self):
        with self._connect() as conn:
            conn.execute('DELETE FROM history')

    def list_history(self, _type):
        with self._connect() as conn:
            cur = conn.execute('SELECT video_id, portal_id, type, series, season_no, title, poster, cmd, last_position, total_seconds FROM history WHERE type = ? ORDER BY updated_ts DESC', (str(_type),))
            rows = cur.fetchall()
        return [{'video_id': r[0], 'portal_id': r[1], 'type': r[2], 'series': r[3], 'season_no': r[4], 'title': r[5], 'poster': r[6], 'cmd': r[7], 'last_position': int(r[8] or 0), 'total_seconds': int(r[9] or 0)} for r in rows]

    def get_progress_item(self, video_id, portal_id, _type, series=0):
        with self._connect() as conn:
            cur = conn.execute('SELECT video_id, portal_id, type, series, season_no, title, poster, cmd, total_episodes, resume_seconds, total_seconds FROM progress WHERE video_id = ? AND portal_id = ? AND type = ? AND series = ? LIMIT 1', (str(video_id), int(portal_id), str(_type), int(series or 0)))
            r = cur.fetchone()
        if not r:
            return None
        resume = int(r[9] or 0)
        total = int(r[10] or 0)
        label = ''
        if total > 0 and resume > 0:
            pct = max(1, min(99, int((resume / float(total)) * 100)))
            label = '{}%'.format(pct)
        elif resume > 0:
            label = '{} min'.format(max(1, int(resume / 60)))
        return {'video_id': r[0], 'portal_id': r[1], 'type': r[2], 'series': r[3], 'season_no': r[4], 'title': r[5], 'poster': r[6], 'cmd': r[7], 'total_episodes': r[8], 'resume_seconds': resume, 'total_seconds': total, 'progress_label': label}

    def get_latest_series_progress(self, video_id, portal_id):
        with self._connect() as conn:
            cur = conn.execute('SELECT video_id, portal_id, type, series, season_no, title, poster, cmd, total_episodes, resume_seconds, total_seconds FROM progress WHERE video_id = ? AND portal_id = ? AND type = ? AND resume_seconds > 0 ORDER BY updated_ts DESC LIMIT 1', (str(video_id), int(portal_id), 'series'))
            r = cur.fetchone()
        if not r:
            return None
        resume = int(r[9] or 0)
        total = int(r[10] or 0)
        label = ''
        if total > 0 and resume > 0:
            pct = max(1, min(99, int((resume / float(total)) * 100)))
            label = '{}%'.format(pct)
        elif resume > 0:
            label = '{} min'.format(max(1, int(resume / 60)))
        return {'video_id': r[0], 'portal_id': r[1], 'type': r[2], 'series': r[3], 'season_no': r[4], 'title': r[5], 'poster': r[6], 'cmd': r[7], 'total_episodes': r[8], 'resume_seconds': resume, 'total_seconds': total, 'progress_label': label}

    def list_series_progress_map(self, video_id, portal_id):
        with self._connect() as conn:
            cur = conn.execute('SELECT series, season_no, title, poster, cmd, total_episodes, resume_seconds, total_seconds FROM progress WHERE video_id = ? AND portal_id = ? AND type = ? AND resume_seconds > 0', (str(video_id), int(portal_id), 'series'))
            rows = cur.fetchall()
        out = {}
        for r in rows:
            resume = int(r[6] or 0)
            total = int(r[7] or 0)
            label = ''
            if total > 0 and resume > 0:
                pct = max(1, min(99, int((resume / float(total)) * 100)))
                label = '{}%'.format(pct)
            elif resume > 0:
                label = '{} min'.format(max(1, int(resume / 60)))
            out[int(r[0] or 0)] = {'series': int(r[0] or 0), 'season_no': int(r[1] or 0), 'title': r[2], 'poster': r[3], 'cmd': r[4], 'total_episodes': int(r[5] or 0), 'resume_seconds': resume, 'total_seconds': total, 'progress_label': label}
        return out

    def list_series_history_map(self, video_id, portal_id):
        with self._connect() as conn:
            cur = conn.execute('SELECT series, last_position, total_seconds FROM history WHERE video_id = ? AND portal_id = ? AND type = ?', (str(video_id), int(portal_id), 'series'))
            rows = cur.fetchall()
        out = {}
        for r in rows:
            out[int(r[0] or 0)] = {'series': int(r[0] or 0), 'last_position': int(r[1] or 0), 'total_seconds': int(r[2] or 0)}
        return out
