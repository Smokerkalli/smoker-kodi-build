# -*- coding: utf-8 -*-
import json
import sys
from urllib.parse import parse_qs, quote_plus, unquote_plus

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
HANDLE = int(sys.argv[1])

DATA_DIR = xbmcvfs.translatePath("special://profile/addon_data/{}".format(ADDON_ID))
FAV_FILE = DATA_DIR + "/favorites.json"


def ensure_data_dir():
    if not xbmcvfs.exists(DATA_DIR):
        xbmcvfs.mkdirs(DATA_DIR)


def load_favs():
    ensure_data_dir()
    if not xbmcvfs.exists(FAV_FILE):
        return []
    fh = xbmcvfs.File(FAV_FILE)
    raw = fh.read()
    fh.close()
    if not raw:
        return []
    try:
        data = json.loads(raw)
        if isinstance(data, list):
            return data
    except Exception:
        pass
    return []


def save_favs(items):
    ensure_data_dir()
    fh = xbmcvfs.File(FAV_FILE, "w")
    fh.write(json.dumps(items, ensure_ascii=False, indent=2))
    fh.close()


def build_url(**kwargs):
    parts = []
    for k, v in kwargs.items():
        parts.append("{}={}".format(k, quote_plus(str(v))))
    return "{}?{}".format(sys.argv[0], "&".join(parts))


def open_target(target):
    if not target:
        xbmcgui.Dialog().notification("Smoker Streams Favoriten", "Kein gültiger Pfad gespeichert", xbmcgui.NOTIFICATION_ERROR)
        return

    if target.startswith("plugin://"):
        xbmc.executebuiltin("ActivateWindow(Videos,{},return)".format(target))
    else:
        xbmc.Player().play(item=target)


def rename_item(index):
    favs = load_favs()
    if index < 0 or index >= len(favs):
        return
    old_name = favs[index].get("name", "")
    keyboard = xbmc.Keyboard(old_name, "Neuen Namen eingeben")
    keyboard.doModal()
    if keyboard.isConfirmed():
        new_name = keyboard.getText().strip()
        if new_name:
            favs[index]["name"] = new_name
            save_favs(favs)
            xbmc.executebuiltin("Container.Refresh")


def remove_item(index):
    favs = load_favs()
    if index < 0 or index >= len(favs):
        return
    del favs[index]
    save_favs(favs)
    xbmc.executebuiltin("Container.Refresh")


def move_item(index, direction):
    favs = load_favs()
    if index < 0 or index >= len(favs):
        return

    new_index = index + direction
    if new_index < 0 or new_index >= len(favs):
        return

    favs[index], favs[new_index] = favs[new_index], favs[index]
    save_favs(favs)
    xbmc.executebuiltin("Container.Refresh")


def clear_all():
    if xbmcgui.Dialog().yesno("Smoker Streams Favoriten", "Wirklich alle Streams-Favoriten löschen?"):
        save_favs([])
        xbmc.executebuiltin("Container.Refresh")


def add_item(name, path, thumb=""):
    if not path:
        xbmcgui.Dialog().notification("Smoker Streams Favoriten", "Kein gültiger Pfad gefunden", xbmcgui.NOTIFICATION_ERROR)
        return

    favs = load_favs()

    for item in favs:
        if item.get("path") == path:
            xbmcgui.Dialog().notification("Smoker Streams Favoriten", "Eintrag schon vorhanden", xbmcgui.NOTIFICATION_INFO)
            return

    favs.append({
        "name": name or "Unbenannter Eintrag",
        "path": path,
        "thumb": thumb or ""
    })
    save_favs(favs)
    xbmcgui.Dialog().notification("Smoker Streams Favoriten", "Eintrag hinzugefügt", xbmcgui.NOTIFICATION_INFO)


def list_items():
    favs = load_favs()

    for i, item in enumerate(favs):
        name = item.get("name", "Unbenannter Eintrag")
        path = item.get("path", "")
        thumb = item.get("thumb", "")

        li = xbmcgui.ListItem(label=name)
        li.setArt({"thumb": thumb, "icon": thumb})

        context_menu = [
            ("Umbenennen", "RunPlugin({})".format(build_url(action="rename", index=i))),
            ("Eintrag entfernen", "RunPlugin({})".format(build_url(action="remove", index=i))),
            ("Nach oben", "RunPlugin({})".format(build_url(action="move", index=i, direction=-1))),
            ("Nach unten", "RunPlugin({})".format(build_url(action="move", index=i, direction=1))),
            ("Alle löschen", "RunPlugin({})".format(build_url(action="clear")))
        ]
        li.addContextMenuItems(context_menu)

        item_url = build_url(action="open", index=i)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=item_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def main():
    params = parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 and sys.argv[2].startswith("?") else {}
    action = params.get("action", [None])[0]

    if action == "open":
        index = int(params.get("index", ["0"])[0])
        favs = load_favs()
        if 0 <= index < len(favs):
            open_target(favs[index].get("path", ""))

    elif action == "add":
        name = unquote_plus(params.get("name", [""])[0])
        path = unquote_plus(params.get("path", [""])[0])
        thumb = unquote_plus(params.get("thumb", [""])[0])
        add_item(name, path, thumb)

    elif action == "rename":
        rename_item(int(params.get("index", ["0"])[0]))

    elif action == "remove":
        remove_item(int(params.get("index", ["0"])[0]))

    elif action == "move":
        index = int(params.get("index", ["0"])[0])
        direction = int(params.get("direction", ["0"])[0])
        move_item(index, direction)

    elif action == "clear":
        clear_all()

    else:
        list_items()


if __name__ == "__main__":
    main()
