# -*- coding: utf-8 -*-
"""Startup maintenance for the FilmPalast edition."""
import time
from resources.lib.config import cConfig
from resources.lib.handler.pluginHandler import cPluginHandler
from resources.lib.handler.requestHandler import cRequestHandler

def main():
    cPluginHandler().checkDomain()
    config = cConfig()
    now = int(time.time())
    interval = 86400 * int(config.getSetting('cacheDeltaDay', 2))
    if now >= int(config.getSetting('lastdelhtml', 0)) + interval:
        cRequestHandler('').clearCache()
        config.setSetting('lastdelhtml', str(now))

if __name__ == '__main__':
    main()
