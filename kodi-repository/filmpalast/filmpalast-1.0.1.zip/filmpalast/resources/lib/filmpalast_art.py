"""Extract listing posters including lazy-loaded images, without network requests."""
import re
from html.parser import HTMLParser

class _Article(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.url = self.title = self.image = ''
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'a' and not self.url and attrs.get('href') and attrs.get('title'):
            self.url, self.title = attrs['href'], attrs['title']
        if tag == 'img' and not self.image:
            for key in ('data-src', 'data-original', 'data-lazy-src', 'src'):
                value = attrs.get(key, '').strip()
                if value and not value.startswith('data:'):
                    self.image = value
                    break
            if not self.image:
                value = attrs.get('data-srcset') or attrs.get('srcset', '')
                if value:
                    self.image = value.split(',')[0].strip().split()[0]

def parse_entries(content):
    entries = []
    for article in re.findall(r'<article\b[^>]*>(.*?)</article\s*>', content, re.I | re.S):
        parser = _Article()
        parser.feed(article)
        if parser.url and parser.title:
            entries.append((parser.url, parser.title, parser.image, article))
    return entries
