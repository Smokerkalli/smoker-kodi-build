# -*- coding: utf-8 -*-
import json
import os
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
DATA_DIR = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}")
FAV_FILE = os.path.join(DATA_DIR, "favorites.json")
CAT_FILE = os.path.join(DATA_DIR, "categories.json")
DEFAULT_CATEGORIES = ['Live TV', 'Sport', 'Filme', 'Serien']


def ensure_data_dir():
    if not xbmcvfs.exists(DATA_DIR):
        xbmcvfs.mkdirs(DATA_DIR)


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_ID}] {msg}", level)


def load_json(path, fallback):
    ensure_data_dir()
    if not xbmcvfs.exists(path):
        return fallback
    try:
        with xbmcvfs.File(path) as fh:
            raw = fh.read()
        if not raw:
            return fallback
        data = json.loads(raw)
        return data
    except Exception as exc:
        log(f"Fehler beim Laden {path}: {exc}", xbmc.LOGERROR)
        return fallback


def save_json(path, data):
    ensure_data_dir()
    try:
        with xbmcvfs.File(path, 'w') as fh:
            fh.write(json.dumps(data, ensure_ascii=False, indent=2))
        return True
    except Exception as exc:
        log(f"Fehler beim Speichern {path}: {exc}", xbmc.LOGERROR)
        return False


def load_favorites():
    data = load_json(FAV_FILE, [])
    return data if isinstance(data, list) else []


def save_favorites(items):
    return save_json(FAV_FILE, items)


def load_categories():
    data = load_json(CAT_FILE, DEFAULT_CATEGORIES[:])
    if not isinstance(data, list):
        data = DEFAULT_CATEGORIES[:]
    cleaned = []
    for entry in data:
        text = str(entry).strip()
        if text and text not in cleaned:
            cleaned.append(text)
    for default in DEFAULT_CATEGORIES:
        if default not in cleaned:
            cleaned.append(default)
    return cleaned


def save_categories(categories):
    cleaned = []
    for entry in categories:
        text = str(entry).strip()
        if text and text not in cleaned:
            cleaned.append(text)
    return save_json(CAT_FILE, cleaned)


def normalize_category(value):
    text = str(value or '').strip()
    return text or DEFAULT_CATEGORIES[0]


def ensure_category_exists(name):
    name = normalize_category(name)
    categories = load_categories()
    if name not in categories:
        categories.append(name)
        save_categories(categories)
    return name


def build_url(**kwargs):
    return BASE_URL + '?' + urllib.parse.urlencode(kwargs)


def notify(title, message, icon=xbmcgui.NOTIFICATION_INFO):
    xbmcgui.Dialog().notification(title, message, icon, 3500)


def get_item_label(item):
    return item.get('label') or item.get('name') or 'Unbenannter Eintrag'


def get_visible_categories(items):
    order = load_categories()
    counts = {}
    for item in items:
        cat = normalize_category(item.get('category'))
        counts[cat] = counts.get(cat, 0) + 1
        if cat not in order:
            order.append(cat)
    save_categories(order)
    visible = [cat for cat in order if counts.get(cat, 0) > 0]
    return visible, counts


def prompt_new_category(default_name=''):
    keyboard = xbmc.Keyboard(default_name, 'Neue Kategorie eingeben')
    keyboard.doModal()
    if not keyboard.isConfirmed():
        return None
    name = keyboard.getText().strip()
    if not name:
        notify('Smoker Live TV Favoriten', 'Kategoriename darf nicht leer sein', xbmcgui.NOTIFICATION_WARNING)
        return None
    return ensure_category_exists(name)


def choose_category(allow_new=True, preselect_name=''):
    categories = load_categories()
    if allow_new:
        options = categories + ['[B]Neue Kategorie...[/B]']
    else:
        options = categories[:]
    preselect = 0
    if preselect_name and preselect_name in categories:
        preselect = categories.index(preselect_name)
    selected = xbmcgui.Dialog().select('Kategorie wählen', options, preselect=preselect)
    if selected < 0:
        return None
    if allow_new and selected == len(categories):
        return prompt_new_category()
    return categories[selected]


def remove_item(index):
    items = load_favorites()
    if index < 0 or index >= len(items):
        return
    removed = items.pop(index)
    if save_favorites(items):
        notify('Smoker Live TV Favoriten', f"Entfernt: {get_item_label(removed)}")
        xbmc.executebuiltin('Container.Refresh')


def move_item(index, direction, category=''):
    items = load_favorites()
    category = normalize_category(category)
    positions = [idx for idx, item in enumerate(items) if normalize_category(item.get('category')) == category]
    if index not in positions:
        return
    pos = positions.index(index)
    new_pos = pos - 1 if direction == 'up' else pos + 1
    if new_pos < 0 or new_pos >= len(positions):
        return
    other_index = positions[new_pos]
    items[index], items[other_index] = items[other_index], items[index]
    if save_favorites(items):
        xbmc.executebuiltin('Container.Refresh')


def rename_item(index):
    items = load_favorites()
    if index < 0 or index >= len(items):
        return
    old_label = get_item_label(items[index])
    keyboard = xbmc.Keyboard(old_label, 'Favorit umbenennen')
    keyboard.doModal()
    if not keyboard.isConfirmed():
        return
    new_label = keyboard.getText().strip()
    if not new_label:
        notify('Smoker Live TV Favoriten', 'Name darf nicht leer sein', xbmcgui.NOTIFICATION_WARNING)
        return
    items[index]['label'] = new_label
    items[index]['name'] = new_label
    if save_favorites(items):
        notify('Smoker Live TV Favoriten', f'Umbenannt: {new_label}')
        xbmc.executebuiltin('Container.Refresh')


def change_category(index):
    items = load_favorites()
    if index < 0 or index >= len(items):
        return
    current = normalize_category(items[index].get('category'))
    selected = choose_category(allow_new=True, preselect_name=current)
    if not selected:
        return
    items[index]['category'] = selected
    ensure_category_exists(selected)
    if save_favorites(items):
        notify('Smoker Live TV Favoriten', f'Verschoben nach: {selected}')
        xbmc.executebuiltin('Container.Refresh')


def clear_category(category):
    category = normalize_category(category)
    if not xbmcgui.Dialog().yesno('Smoker Live TV Favoriten', f'Alle Favoriten in „{category}“ löschen?'):
        return
    items = load_favorites()
    kept = [item for item in items if normalize_category(item.get('category')) != category]
    if save_favorites(kept):
        notify('Smoker Live TV Favoriten', f'Kategorie geleert: {category}')
        xbmc.executebuiltin('Container.Refresh')


def clear_all():
    if not xbmcgui.Dialog().yesno('Smoker Live TV Favoriten', 'Alle Einträge löschen?'):
        return
    if save_favorites([]):
        notify('Smoker Live TV Favoriten', 'Alle Einträge gelöscht')
        xbmc.executebuiltin('Container.Refresh')


def rename_category(category):
    category = normalize_category(category)
    new_name = prompt_new_category(category)
    if not new_name or new_name == category:
        return
    items = load_favorites()
    for item in items:
        if normalize_category(item.get('category')) == category:
            item['category'] = new_name
    categories = load_categories()
    categories = [new_name if c == category else c for c in categories]
    deduped = []
    for c in categories:
        if c not in deduped:
            deduped.append(c)
    if save_favorites(items) and save_categories(deduped):
        notify('Smoker Live TV Favoriten', f'Kategorie umbenannt: {new_name}')
        xbmc.executebuiltin('Container.Refresh')


def delete_category(category):
    category = normalize_category(category)
    options = ['Nur Kategorie entfernen (Einträge nach Live TV)', 'Kategorie mit allen Einträgen löschen']
    selected = xbmcgui.Dialog().select(f'Kategorie löschen: {category}', options)
    if selected < 0:
        return
    items = load_favorites()
    categories = [c for c in load_categories() if c != category]
    if selected == 0:
        fallback = ensure_category_exists(DEFAULT_CATEGORIES[0])
        for item in items:
            if normalize_category(item.get('category')) == category:
                item['category'] = fallback
        saved = save_favorites(items) and save_categories(categories)
        if saved:
            notify('Smoker Live TV Favoriten', f'Kategorie entfernt: {category}')
    else:
        items = [item for item in items if normalize_category(item.get('category')) != category]
        saved = save_favorites(items) and save_categories(categories)
        if saved:
            notify('Smoker Live TV Favoriten', f'Kategorie gelöscht: {category}')
    xbmc.executebuiltin('Container.Refresh')


def list_categories():
    items = load_favorites()
    visible_categories, counts = get_visible_categories(items)

    if not visible_categories:
        li = xbmcgui.ListItem(label='Noch keine Favoriten')
        li.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
        li.setInfo('video', {'plot': 'Füge per Rechtsklick Einträge zu Smoker Live TV Favoriten hinzu.'})
        xbmcplugin.addDirectoryItem(HANDLE, '', li, False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for category in visible_categories:
        count = counts.get(category, 0)
        li = xbmcgui.ListItem(label=category)
        li.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
        li.setInfo('video', {'plot': f'{count} Einträge'})
        cm = [
            ('Kategorie umbenennen', f'RunPlugin({build_url(action="rename_category", category=category)})'),
            ('Kategorie löschen', f'RunPlugin({build_url(action="delete_category", category=category)})'),
            ('Kategorie leeren', f'RunPlugin({build_url(action="clear_category", category=category)})'),
            ('Alle Favoriten löschen', f'RunPlugin({build_url(action="clear_all")})')
        ]
        li.addContextMenuItems(cm, replaceItems=False)
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action='category', category=category), li, True)

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)


def list_favorites(category):
    category = normalize_category(category)
    items = load_favorites()
    category_items = [(idx, item) for idx, item in enumerate(items) if normalize_category(item.get('category')) == category]

    if not category_items:
        li = xbmcgui.ListItem(label='Noch keine Favoriten in dieser Kategorie')
        li.setInfo('video', {'plot': f'Füge per Rechtsklick Einträge hinzu und wähle {category}.'})
        xbmcplugin.addDirectoryItem(HANDLE, '', li, False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for pos, (idx, item) in enumerate(category_items):
        label = get_item_label(item)
        thumb = item.get('thumb') or ''
        fanart = item.get('fanart') or ''
        target = item.get('target') or item.get('path') or ''
        item_type = item.get('item_type') or 'folder'
        li = xbmcgui.ListItem(label=label)
        if thumb or fanart:
            li.setArt({'thumb': thumb, 'icon': thumb or 'DefaultFolder.png', 'fanart': fanart})
        li.setProperty('IsPlayable', 'true' if item_type == 'playable' else 'false')
        source = item.get('source_label', 'Unbekannt')
        li.setInfo('video', {'plot': f'Quelle: {source}\nKategorie: {category}'})
        cm = [
            ('Umbenennen', f'RunPlugin({build_url(action="rename", index=idx)})'),
            ('Kategorie ändern', f'RunPlugin({build_url(action="change_category", index=idx)})'),
            ('Aus Smoker Live TV Favoriten entfernen', f'RunPlugin({build_url(action="remove", index=idx)})')
        ]
        if pos > 0:
            cm.append(('Nach oben verschieben', f'RunPlugin({build_url(action="move", index=idx, direction="up", category=category)})'))
        if pos < len(category_items) - 1:
            cm.append(('Nach unten verschieben', f'RunPlugin({build_url(action="move", index=idx, direction="down", category=category)})'))
        li.addContextMenuItems(cm, replaceItems=False)
        url = target
        is_folder = item_type != 'playable'
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=is_folder)

    xbmcplugin.setPluginCategory(HANDLE, category)
    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)


def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get('action')
    category = params.get('category', '')
    if action == 'remove':
        remove_item(int(params.get('index', '-1')))
    elif action == 'move':
        move_item(int(params.get('index', '-1')), params.get('direction', 'up'), category)
    elif action == 'rename':
        rename_item(int(params.get('index', '-1')))
    elif action == 'change_category':
        change_category(int(params.get('index', '-1')))
    elif action == 'clear_category':
        clear_category(category)
    elif action == 'clear_all':
        clear_all()
    elif action == 'rename_category':
        rename_category(category)
    elif action == 'delete_category':
        delete_category(category)
    elif action == 'category':
        list_favorites(category)
    else:
        list_categories()


if __name__ == '__main__':
    router(sys.argv[2][1:] if len(sys.argv) > 2 else '')
