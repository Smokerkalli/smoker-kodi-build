from __future__ import annotations

def is_valid_item(name):
    if not name:
        return True
    name_low = name.lower()
    blocked = ['4.3', 'old', 'deprecated', 'legacy']
    return not any(b in name_low for b in blocked)


# -*- coding: utf-8 -*-
import os
import sys
import json
import gzip
import shutil
import hashlib
import traceback
from urllib.parse import urlencode, parse_qsl, quote, urlparse
from xml.etree import ElementTree as ET
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin


# ===== CLEAN INTERNAL FAVORITES =====
import xbmcvfs

FAV_FILE = xbmcvfs.translatePath('special://profile/addon_data/plugin.program.smoker.quellen/favorites.json')

def load_favs():
    try:
        f = xbmcvfs.File(FAV_FILE)
        data = f.read()
        f.close()
        return json.loads(data) if data else []
    except Exception:
        return []

def save_favs(data):
    folder = os.path.dirname(FAV_FILE)
    if not xbmcvfs.exists(folder):
        xbmcvfs.mkdirs(folder)
    f = xbmcvfs.File(FAV_FILE, 'w')
    f.write(json.dumps(data, ensure_ascii=False))
    f.close()

def add_fav(name, url, icon='', addon_type='favorite', addon_id=''):
    if not url:
        return
    favs = load_favs()
    if not any(str(x.get('url')) == str(url) for x in favs):
        favs.append({
            'name': name or 'Unbenannt',
            'url': url,
            'icon': icon or '',
            'addon_type': addon_type or 'favorite',
            'addon_id': addon_id or '',
        })
        save_favs(favs)
        notify('Zu Smoker Favoriten hinzugefügt')

def remove_fav(name):
    favs = [f for f in load_favs() if f.get('name') != name]
    save_favs(favs)
    notify('Favorit entfernt')

def list_favs():
    xbmcplugin.setPluginCategory(HANDLE, 'Smoker Favoriten')
    add_item('⬅️ Zurück zum Hauptmenü', {'action': 'root'}, folder=True, info_label='Zurück zum Hauptmenü')
    favs = load_favs()
    if not favs:
        add_item('Keine Smoker Favoriten vorhanden', None, folder=False, info_label='Füge Addons über das Addon-Menü hinzu')
        xbmcplugin.endOfDirectory(HANDLE)
        return
    for fav in favs:
        name = fav.get('name', 'Unbenannt')
        url = fav.get('url', '')
        icon = fav.get('icon', '') or ICON
        addon_type = fav.get('addon_type', 'favorite')
        addon_id = fav.get('addon_id', '')
        info = addon_id or url
        context = [
            ('❌ Entfernen', 'RunPlugin({})'.format(build_url({'action':'remove_fav','name':name}))),
        ]
        add_item('⭐ ' + name, {'action':'item_menu', 'source_id':'', 'zip_url':url, 'name':name, 'version':'', 'addon_type':addon_type, 'addon_id':addon_id}, folder=True, context=context, info_label=info, art=icon)
    xbmcplugin.endOfDirectory(HANDLE)

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = sys.argv[0] if len(sys.argv) > 0 else f'plugin://{ADDON_ID}/'
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
DATA_DIR = os.path.join(PROFILE, 'data')
SOURCES_FILE = os.path.join(DATA_DIR, 'sources.json')
CACHE_FILE = os.path.join(DATA_DIR, 'scan_cache.json')
ICON = xbmcvfs.translatePath(ADDON.getAddonInfo('icon'))
FANART = xbmcvfs.translatePath(ADDON.getAddonInfo('fanart'))

FIXED_SOURCES = [
    {
        'id': 'fixed_michaz',
        'name': 'Michaz Repo [Fest]',
        'url': 'http://michaz1988.github.io/repo',
        'mode': 'auto',
        'locked': True,
    },
    {
        'id': 'fixed_teamcrashx',
        'name': 'TeamCr4sh Repo [Fest]',
        'url': 'https://teamcrashx.github.io/repo',
        'mode': 'auto',
        'locked': True,
    },
]

FILTERS = [
    ('all', 'Alle'),
    ('repository', 'Repositories'),
    ('video', 'Video Addons'),
    ('program', 'Programme'),
    ('script', 'Scripts'),
    ('skin', 'Skins'),
    ('wizard', 'Wizards'),
    ('other', 'Andere'),
]


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'[{ADDON_ID}] {msg}', level)


def ensure_dirs():
    for path in (PROFILE, DATA_DIR):
        if not xbmcvfs.exists(path):
            xbmcvfs.mkdirs(path)


def notify(message, error=False):
    icon = xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO
    xbmcgui.Dialog().notification(ADDON_NAME, message, icon)


def join_url(base, *parts):
    base = str(base).rstrip('/')
    cleaned = [str(p).strip('/') for p in parts if p is not None and str(p).strip('/')]
    return base + ('/' + '/'.join(cleaned) if cleaned else '')


def build_url(query):
    return BASE_URL + '?' + urlencode(query)


def read_setting_int(key, default):
    try:
        return int(ADDON.getSetting(key) or default)
    except Exception:
        return default


def read_setting_bool(key, default):
    try:
        value = ADDON.getSetting(key)
        if value == '':
            return default
        return value.lower() == 'true'
    except Exception:
        return default


def download_dir():
    path = ADDON.getSetting('download_dir') or 'special://home/addons/packages'
    return xbmcvfs.translatePath(path)


def http_get(url, binary=False):
    timeout = read_setting_int('timeout', 15)
    req = Request(url, headers={'User-Agent': 'Kodi/KalliSourceManager'})
    try:
        with urlopen(req, timeout=timeout) as resp:
            return resp.read() if binary else resp.read().decode('utf-8', 'replace')
    except HTTPError as e:
        raise RuntimeError(f'HTTP {e.code}')
    except URLError as e:
        raise RuntimeError(f'URL Fehler: {e.reason}')


def load_json(path, default):
    try:
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception as exc:
        log(f'JSON load failed {path}: {exc}', xbmc.LOGERROR)
    return default


def save_json(path, data):
    ensure_dirs()
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def normalize_source(src, index=0):
    src = dict(src or {})
    src.setdefault('id', f'user_{index}_{hashlib.md5((src.get("name","")+src.get("url","")).encode("utf-8")).hexdigest()[:8]}')
    src.setdefault('name', f'Quelle {index+1}')
    src.setdefault('url', '')
    src.setdefault('mode', 'auto')
    src.setdefault('locked', False)
    return src


def load_sources():
    ensure_dirs()
    raw = load_json(SOURCES_FILE, [])
    users = [normalize_source(s, i) for i, s in enumerate(raw)]
    fixed_ids = {s['id'] for s in FIXED_SOURCES}
    users = [s for s in users if s['id'] not in fixed_ids]
    return FIXED_SOURCES + users


def save_user_sources(sources):
    fixed_ids = {s['id'] for s in FIXED_SOURCES}
    users = [s for s in sources if s.get('id') not in fixed_ids]
    save_json(SOURCES_FILE, users)


def cache_load():
    return load_json(CACHE_FILE, {})


def cache_save(cache):
    save_json(CACHE_FILE, cache)


def detect_type(addon_id, addon_name='', extension_point=''):
    aid = (addon_id or '').lower()
    ept = (extension_point or '').lower()
    name = (addon_name or '').lower()
    if aid.startswith('repository.') or ept == 'xbmc.addon.repository':
        return 'repository'
    if aid.startswith('plugin.video.'):
        return 'video'
    if aid.startswith('plugin.program.'):
        return 'program'
    if aid.startswith('script.') or aid.startswith('service.') or aid.startswith('context.') or aid.startswith('metadata.') or aid.startswith('resource.images.'):
        if 'wizard' in aid or 'wizard' in name:
            return 'wizard'
        return 'script'
    if aid.startswith('skin.'):
        return 'skin'
    if aid.startswith('resource.'):
        return 'other'
    if ept == 'xbmc.python.pluginsource':
        if aid.startswith('plugin.program.'):
            return 'program'
        return 'video'
    if 'wizard' in aid or 'wizard' in name:
        return 'wizard'
    return 'other'


def scan_addons_xml(source):
    base = source['url'].rstrip('/')
    candidates = [join_url(base, 'addons.xml'), join_url(base, 'addons.xml.gz')]
    xml_text = None
    used = None
    for candidate in candidates:
        try:
            if candidate.endswith('.gz'):
                data = http_get(candidate, binary=True)
                xml_text = gzip.decompress(data).decode('utf-8', 'replace')
            else:
                xml_text = http_get(candidate)
            used = candidate
            break
        except Exception:
            continue
    if not xml_text:
        return []
    root = ET.fromstring(xml_text)
    items = []
    for addon in root.findall('addon'):
        addon_id = addon.attrib.get('id', '')
        version = addon.attrib.get('version', '')
        name = addon.attrib.get('name', addon_id)
        extension = addon.find('extension')
        point = extension.attrib.get('point', '') if extension is not None else ''
        icon = addon.findtext('assets/icon', default='')
        fanart = addon.findtext('assets/fanart', default='')
        folder = addon_id
        filename = f'{addon_id}-{version}.zip' if version else f'{addon_id}.zip'
        items.append({
            'addon_id': addon_id,
            'name': name,
            'version': version,
            'type': detect_type(addon_id, name, point),
            'path': f'{folder}/{filename}',
            'url': join_url(base, folder, filename),
            'icon': join_url(base, folder, icon) if icon else '',
            'fanart': join_url(base, folder, fanart) if fanart else '',
            'source_mode': 'addons_xml',
            'extension_point': point,
            'source_info': used,
        })
    return items


def scan_http_repo(source):
    repo_url = source['url'].rstrip('/')
    items = []
    visited = set()

    def _scan(current_url, rel_path=''):
        if current_url in visited:
            return
        visited.add(current_url)
        try:
            dirs, files = xbmcvfs.listdir(current_url)
        except Exception as exc:
            log(f'listdir failed {current_url}: {exc}', xbmc.LOGWARNING)
            return
        for f in files or []:
            if f.lower().endswith('.zip'):
                path = '/'.join([p for p in [rel_path, f] if p])
                filename = os.path.basename(f)
                addon_id = filename.rsplit('-', 1)[0] if '-' in filename else filename[:-4]
                version = filename[len(addon_id)+1:-4] if filename.startswith(addon_id + '-') else ''
                items.append({
                    'addon_id': addon_id,
                    'name': addon_id,
                    'version': version,
                    'type': detect_type(addon_id, addon_id, ''),
                    'path': path,
                    'url': join_url(repo_url, path),
                    'icon': '',
                    'fanart': '',
                    'source_mode': 'http_dir',
                    'extension_point': '',
                    'source_info': current_url,
                })
        for d in dirs or []:
            next_url = join_url(current_url, d)
            next_rel = '/'.join([p for p in [rel_path, d] if p])
            _scan(next_url, next_rel)

    _scan(repo_url)
    return items


def scan_html_zip(source):
    html = http_get(source['url'])
    items = []
    for chunk in html.split('href='):
        if '.zip' not in chunk.lower():
            continue
        quote_char = '"' if '"' in chunk[:2] else "'"
        parts = chunk.split(quote_char)
        if len(parts) < 2:
            continue
        href = parts[1]
        if '.zip' not in href.lower():
            continue
        if href.startswith('http://') or href.startswith('https://'):
            full = href
        else:
            full = join_url(source['url'], href)
        filename = os.path.basename(urlparse(full).path)
        addon_id = filename.rsplit('-', 1)[0] if '-' in filename else filename[:-4]
        version = filename[len(addon_id)+1:-4] if filename.startswith(addon_id + '-') else ''
        items.append({
            'addon_id': addon_id,
            'name': addon_id,
            'version': version,
            'type': detect_type(addon_id, addon_id, ''),
            'path': filename,
            'url': full,
            'icon': '',
            'fanart': '',
            'source_mode': 'html_zip',
            'extension_point': '',
            'source_info': source['url'],
        })
    uniq = {}
    for it in items:
        uniq[it['url']] = it
    return list(uniq.values())


def scan_source(source):
    mode = source.get('mode', 'auto')
    if mode == 'direct_zip':
        filename = os.path.basename(urlparse(source['url']).path)
        addon_id = filename.rsplit('-', 1)[0] if '-' in filename else filename[:-4]
        return [{
            'addon_id': addon_id,
            'name': addon_id,
            'version': '',
            'type': detect_type(addon_id),
            'path': filename,
            'url': source['url'],
            'icon': '',
            'fanart': '',
            'source_mode': 'direct_zip',
            'extension_point': '',
            'source_info': source['url'],
        }]
    scanners = []
    if mode == 'addons_xml':
        scanners = [scan_addons_xml]
    elif mode == 'http_dir':
        scanners = [scan_http_repo]
    elif mode == 'html_zip':
        scanners = [scan_html_zip]
    else:
        scanners = [scan_addons_xml, scan_http_repo, scan_html_zip]
    for scanner in scanners:
        try:
            items = scanner(source)
            if items:
                return items
        except Exception as exc:
            log(f'scanner {scanner.__name__} failed for {source.get("url")}: {exc}', xbmc.LOGWARNING)
    return []


def get_source(source_id):
    for src in load_sources():
        if src.get('id') == source_id:
            return src
    return None


def sort_items(items):
    return sorted(items, key=lambda x: ((x.get('type') or 'zzz'), (x.get('name') or '').lower()))


def refresh_container():
    xbmc.executebuiltin('Container.Refresh')


def add_item(label, query=None, folder=False, context=None, info_label='', art=None):
    url = build_url(query or {}) if query is not None else ''
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': art or ICON, 'thumb': art or ICON, 'fanart': FANART})
    if info_label:
        li.setLabel2(info_label)
        li.setProperty('Addon.Description', info_label)
        li.setProperty('Plot', info_label)
    if context:
        li.addContextMenuItems(context, replaceItems=True)
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=folder)



def root_listing():
    xbmcplugin.setPluginCategory(HANDLE, 'Smoker Quellen 4.3 Clean')
    add_item('➕ Quelle hinzufügen', {'action': 'add_source'}, folder=False, info_label='Neue Quelle anlegen')
    add_item('⭐ Smoker Favoriten', {'action': 'show_favs'}, folder=True, info_label='Eigene Favoriten nur im Addon')
    add_item('⚙️ Einstellungen', {'action': 'open_settings'}, folder=False, info_label='Addon Einstellungen öffnen')
    for src in load_sources():
        info = "{}\\nModus: {}".format(src.get('url', ''), src.get('mode', 'auto'))
        context = [
            ('Quelle testen', 'RunPlugin({})'.format(build_url({'action':'test_source','source_id':src['id']}))),
            ('Repo-Menü öffnen', 'Container.Update({})'.format(build_url({'action':'browse_source','source_id':src['id']}))),
            ('Quelle bearbeiten', 'RunPlugin({})'.format(build_url({'action':'edit_source','source_id':src['id']}))),
        ]
        if not src.get('locked'):
            context.append(('Quelle löschen', 'RunPlugin({})'.format(build_url({'action':'delete_source','source_id':src['id']}))))
        add_item(src.get('name', 'Quelle'), {'action': 'browse_source', 'source_id': src.get('id')}, folder=True, context=context, info_label=info)
    xbmcplugin.endOfDirectory(HANDLE)

def choose_mode(current='auto'):
    values = [
        ('auto', 'Auto'),
        ('addons_xml', 'Kodi Repo / addons.xml'),
        ('http_dir', 'HTTP-Ordner'),
        ('html_zip', 'HTML ZIP Scanner'),
        ('direct_zip', 'Direkter ZIP-Link'),
    ]
    labels = [v[1] for v in values]
    pre = next((i for i, v in enumerate(values) if v[0] == current), 0)
    idx = xbmcgui.Dialog().select('Modus wählen', labels, preselect=pre)
    return values[idx][0] if idx >= 0 else None


def add_source():
    name = xbmcgui.Dialog().input('Name der Quelle', type=xbmcgui.INPUT_ALPHANUM)
    if not name:
        return
    url = xbmcgui.Dialog().input('URL der Quelle', type=xbmcgui.INPUT_ALPHANUM)
    if not url:
        return
    mode = choose_mode('auto')
    if not mode:
        return
    sources = load_sources()
    src = normalize_source({'name': name, 'url': url, 'mode': mode}, len(sources))
    sources.append(src)
    save_user_sources(sources)
    notify('Quelle hinzugefügt')
    refresh_container()


def edit_source(source_id):
    src = get_source(source_id)
    if not src:
        notify('Quelle nicht gefunden', True)
        return
    if src.get('locked'):
        notify('Feste Quelle kann nicht bearbeitet werden', True)
        return
    name = xbmcgui.Dialog().input('Name der Quelle', defaultt=src.get('name',''), type=xbmcgui.INPUT_ALPHANUM)
    if not name:
        return
    url = xbmcgui.Dialog().input('URL der Quelle', defaultt=src.get('url',''), type=xbmcgui.INPUT_ALPHANUM)
    if not url:
        return
    mode = choose_mode(src.get('mode', 'auto'))
    if not mode:
        return
    sources = load_sources()
    for item in sources:
        if item.get('id') == source_id:
            item['name'] = name
            item['url'] = url
            item['mode'] = mode
            break
    save_user_sources(sources)
    notify('Quelle gespeichert')
    refresh_container()


def delete_source(source_id):
    src = get_source(source_id)
    if not src:
        return
    if src.get('locked'):
        notify('Feste Quelle kann nicht gelöscht werden', True)
        return
    if not xbmcgui.Dialog().yesno(ADDON_NAME, f'Quelle "{src.get("name")}" löschen?'):
        return
    sources = [s for s in load_sources() if s.get('id') != source_id]
    save_user_sources(sources)
    notify('Quelle gelöscht')
    refresh_container()


def test_source(source_id):
    src = get_source(source_id)
    if not src:
        notify('Quelle nicht gefunden', True)
        return
    try:
        items = scan_source(src)
        notify(f'Quelle ok: {len(items)} Einträge gefunden') if items else notify('Quelle erreichbar, aber keine Einträge gefunden', True)
    except Exception as exc:
        notify(f'Fehler: {exc}', True)




def browse_source(source_id, filter_key='all'):
    src = get_source(source_id)
    if not src:
        notify('Quelle nicht gefunden', True)
        return root_listing()

    cache = cache_load()
    items = cache.get(source_id)
    if not items:
        items = scan_source(src)
        cache[source_id] = items
        cache_save(cache)

    items = sort_items(items)
    counts = {'all': len(items)}
    for key, _ in FILTERS:
        if key != 'all':
            counts[key] = len([x for x in items if str(x.get('type', 'other')).strip().lower() == key])

    xbmcplugin.setPluginCategory(HANDLE, '{} – Kategorien'.format(src.get('name')))

    add_item('Alle Addons', {'action': 'cat_all', 'source_id': source_id}, folder=True, info_label='{} Einträge'.format(counts.get('all', 0)))
    add_item('Repositories', {'action': 'cat_repository', 'source_id': source_id}, folder=True, info_label='{} Einträge'.format(counts.get('repository', 0)))
    add_item('Video Addons', {'action': 'cat_video', 'source_id': source_id}, folder=True, info_label='{} Einträge'.format(counts.get('video', 0)))
    add_item('Programme', {'action': 'cat_program', 'source_id': source_id}, folder=True, info_label='{} Einträge'.format(counts.get('program', 0)))
    add_item('Scripts', {'action': 'cat_script', 'source_id': source_id}, folder=True, info_label='{} Einträge'.format(counts.get('script', 0)))
    add_item('Skins', {'action': 'cat_skin', 'source_id': source_id}, folder=True, info_label='{} Einträge'.format(counts.get('skin', 0)))
    add_item('Wizards', {'action': 'cat_wizard', 'source_id': source_id}, folder=True, info_label='{} Einträge'.format(counts.get('wizard', 0)))
    add_item('Andere', {'action': 'cat_other', 'source_id': source_id}, folder=True, info_label='{} Einträge'.format(counts.get('other', 0)))
    add_item('Repo neu scannen', {'action': 'rescan_source', 'source_id': source_id, 'filter': filter_key}, folder=False, info_label='Cache leeren und neu scannen')
    xbmcplugin.endOfDirectory(HANDLE)

def browse_category(source_id, filter_key='all'):
    src = get_source(source_id)
    if not src:
        notify('Quelle nicht gefunden', True)
        return root_listing()

    cache = cache_load()
    items = cache.get(source_id)
    if not items:
        items = scan_source(src)
        cache[source_id] = items
        cache_save(cache)

    items = sort_items(items)

    selected_key = (filter_key or 'all').strip().lower()
    if selected_key == 'all':
        filtered = list(items)
    else:
        filtered = [x for x in items if str(x.get('type', 'other')).strip().lower() == selected_key]

    current_label = next((label for key, label in FILTERS if key == selected_key), 'Alle Addons')
    xbmcplugin.setPluginCategory(HANDLE, '{} – {}'.format(src.get('name'), current_label))

    add_item('⬅️ Zurück zu Kategorien', {'action': 'browse_source', 'source_id': source_id}, folder=True, info_label=src.get('url', ''))
    if not filtered:
        add_item('Keine Einträge in dieser Kategorie', None, folder=False, info_label='Diese Kategorie ist aktuell leer.')
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for item in filtered:
        version = item.get('version') or '?'
        addon_name = item.get('name', 'Unbekannt')
        if 'smoker quellen' in addon_name.lower():
            addon_name = 'Smoker Quellen (aktuell)'
        addon_id = item.get('addon_id', '')
        info = '{} · Version {}'.format(addon_id, version)
        item_context = [
            ('⭐ Zu Smoker Favoriten', 'RunPlugin({})'.format(build_url({
                'action':'add_fav',
                'name':addon_name,
                'url':item.get('url',''),
                'icon':item.get('icon',''),
                'addon_type':item.get('type','other'),
                'addon_id':addon_id
            }))),
        ]
        add_item(addon_name, {
            'action': 'item_menu',
            'source_id': source_id,
            'zip_url': item.get('url', ''),
            'name': addon_name,
            'version': version,
            'addon_type': item.get('type', 'other'),
            'addon_id': addon_id,
        }, folder=True, context=item_context, info_label=info, art=item.get('icon') or ICON)

    xbmcplugin.endOfDirectory(HANDLE)

def rescan_source(source_id, filter_key='all'):
    src = get_source(source_id)
    if not src:
        notify('Quelle nicht gefunden', True)
        return
    items = scan_source(src)
    cache = cache_load()
    cache[source_id] = items
    cache_save(cache)
    notify(f'Repo neu gescannt: {len(items)} Einträge')
    xbmc.executebuiltin(f'ActivateWindow(Videos,{build_url({"action":"browse_source","source_id":source_id,"filter":filter_key})},return)')


def item_menu(source_id, zip_url, name, version='', addon_type='other', addon_id=''):
    type_labels = {
        'repository': 'Repository',
        'video': 'Video Addon',
        'program': 'Programm',
        'script': 'Script',
        'skin': 'Skin',
        'wizard': 'Wizard',
        'favorite': 'Favorit',
        'other': 'Anderes Addon',
    }
    pretty_type = type_labels.get(addon_type, addon_type)
    info = 'ID: {}\nTyp: {}\nVersion: {}\nURL: {}'.format(addon_id, pretty_type, version, zip_url)
    add_item('⭐ Zu Smoker Favoriten', {'action': 'add_fav', 'name': name, 'url': zip_url, 'icon': ICON, 'addon_type': addon_type, 'addon_id': addon_id}, folder=False, info_label='Nur im Addon speichern')
    add_item('⬇️ Herunterladen', {'action': 'download_zip', 'zip_url': zip_url, 'name': name}, folder=False, info_label='ZIP in packages speichern')
    add_item('⚡ Installieren', {'action': 'install_zip', 'zip_url': zip_url, 'name': name}, folder=False, info_label='ZIP herunterladen und lokal installieren')
    add_item('URL: {}'.format(zip_url), None, folder=False, info_label=info)
    xbmcplugin.endOfDirectory(HANDLE)

def safe_filename(name):
    return ''.join(c for c in name if c.isalnum() or c in ('-', '_', '.')).strip() or 'addon.zip'


def download_file(zip_url, name):
    if not zip_url:
        raise RuntimeError('Keine ZIP-URL vorhanden')
    out_dir = download_dir()
    if not os.path.isdir(out_dir):
        os.makedirs(out_dir, exist_ok=True)
    filename = safe_filename(os.path.basename(urlparse(zip_url).path) or f'{name}.zip')
    dest = os.path.join(out_dir, filename)
    data = http_get(zip_url, binary=True)
    with open(dest, 'wb') as f:
        f.write(data)
    return dest


def download_zip(zip_url, name):
    try:
        dest = download_file(zip_url, name)
        notify(f'Gespeichert: {os.path.basename(dest)}')
    except Exception as exc:
        notify(f'Download fehlgeschlagen: {exc}', True)


def install_zip(zip_url, name):
    try:
        dest = download_file(zip_url, name)
        xbmc.executebuiltin(f'InstallFromZip({dest})')
        notify(f'Install gestartet: {os.path.basename(dest)}')
    except Exception as exc:
        notify(f'Install fehlgeschlagen: {exc}', True)


def open_settings():
    ADDON.openSettings()


def router(paramstring):
    params = dict(parse_qsl(paramstring)) if paramstring else {}
    action = params.get('action')
    try:
        if action == 'root':
            return root_listing()
        if action == 'add_source':
            return add_source()
        if action == 'edit_source':
            return edit_source(params.get('source_id'))
        if action == 'delete_source':
            return delete_source(params.get('source_id'))
        if action == 'test_source':
            return test_source(params.get('source_id'))
        if action == 'browse_source':
            return browse_source(params.get('source_id'), params.get('filter', 'all'))
        if action == 'browse_category':
            return browse_category(params.get('source_id'), params.get('filter', 'all'))
        if action == 'cat_all':
            return browse_category(params.get('source_id'), 'all')
        if action == 'cat_repository':
            return browse_category(params.get('source_id'), 'repository')
        if action == 'cat_video':
            return browse_category(params.get('source_id'), 'video')
        if action == 'cat_program':
            return browse_category(params.get('source_id'), 'program')
        if action == 'cat_script':
            return browse_category(params.get('source_id'), 'script')
        if action == 'cat_skin':
            return browse_category(params.get('source_id'), 'skin')
        if action == 'cat_wizard':
            return browse_category(params.get('source_id'), 'wizard')
        if action == 'cat_other':
            return browse_category(params.get('source_id'), 'other')
        if action == 'show_favs':
            return list_favs()
        if action == 'add_fav':
            return add_fav(
                params.get('name'),
                params.get('url'),
                params.get('icon',''),
                params.get('addon_type','favorite'),
                params.get('addon_id','')
            )
        if action == 'remove_fav':
            return remove_fav(params.get('name'))
        if action == 'rescan_source':
            return rescan_source(params.get('source_id'), params.get('filter', 'all'))
        if action == 'item_menu':
            return item_menu(params.get('source_id'), params.get('zip_url'), params.get('name'), params.get('version',''), params.get('addon_type','other'), params.get('addon_id',''))
        if action == 'download_zip':
            return download_zip(params.get('zip_url'), params.get('name'))
        if action == 'install_zip':
            return install_zip(params.get('zip_url'), params.get('name'))
        if action == 'open_settings':
            return open_settings()
        return root_listing()
    except Exception as exc:
        log('Unhandled error: {}\n{}'.format(exc, traceback.format_exc()), xbmc.LOGERROR)
        notify(str(exc), True)
        return root_listing()

if __name__ == '__main__':
    ensure_dirs()
    router(sys.argv[2][1:] if len(sys.argv) > 2 else '')
