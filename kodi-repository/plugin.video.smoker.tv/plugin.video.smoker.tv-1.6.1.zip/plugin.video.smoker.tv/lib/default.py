# -*- coding: utf-8 -*-
import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import requests
import json

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ICON_BASE = "special://home/addons/plugin.video.smoker.tv/resources/media/icons/"
FANART = "special://home/addons/plugin.video.smoker.tv/fanart_smoker_v2.png"



def get_timeout(default=6):
    try:
        value = int(ADDON.getSetting("request_timeout") or default)
        return max(3, min(30, value))
    except Exception:
        return default


def build_url(params):
    return BASE_URL + "?" + urllib.parse.urlencode(params)


GROUP_NAMES = {
    "DE": "Deutschland",
    "AT": "Österreich",
    "CH": "Schweiz",
    "FR": "Frankreich",
    "BG": "Bulgarien",
    "TR": "Türkei",
    "IT": "Italien",
    "ES": "Spanien",
    "BALKAN": "Balkan",
    "ARABIC": "Arabisch",
    "INTERNATIONAL": "International",
    "SPORT": "Sport",
    "KIDS": "Kinder",
    "MOVIES": "Filme",
    "SERIES": "Serien"
}


def load_vavoo_groups():
    try:
        url = "https://www2.vavoo.to/live2/index?output=json"
        data = requests.get(url, timeout=get_timeout(5)).json()
        groups = []
        for item in data:
            g = item.get("group")
            if g and g not in groups:
                groups.append(g)
        return groups
    except:
        return []


def choose_countries():
    groups = load_vavoo_groups()
    if not groups:
        xbmcgui.Dialog().notification("Fehler", "Keine Gruppen gefunden", xbmcgui.NOTIFICATION_ERROR)
        return

    display = [GROUP_NAMES.get(g, g) for g in groups]

    try:
        old = json.loads(ADDON.getSetting("country_groups"))
    except:
        old = []

    preselect = [groups.index(g) for g in old if g in groups]

    selected = xbmcgui.Dialog().multiselect("Länder wählen", display, preselect=preselect)
    if selected is None:
        return

    chosen = [groups[i] for i in selected]
    ADDON.setSetting("country_groups", json.dumps(chosen))
    xbmcgui.Dialog().notification("Gespeichert", "Länderauswahl aktualisiert", xbmcgui.NOTIFICATION_INFO)


def _status(ok):
    return "OK" if ok else "FEHLER"


def run_system_check():
    lines = []

    has_adaptive = xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)")
    has_ffmpeg = xbmc.getCondVisibility("System.HasAddon(inputstream.ffmpegdirect)")

    lines.append("=== Addon / Player ===")
    lines.append("inputstream.adaptive: %s" % _status(has_adaptive))
    lines.append("inputstream.ffmpegdirect: %s" % _status(has_ffmpeg))
    lines.append("")

    lines.append("=== Aktive Einstellungen ===")
    stream_mode = "Manuell" if ADDON.getSetting("stream_select") == "0" else "Automatisch"
    lines.append("Stream-Auswahl: %s" % stream_mode)
    lines.append("Auto nächster Stream: %s" % ("AN" if ADDON.getSettingBool("auto_try_next_stream") else "AUS"))
    lines.append("InputStream nutzen: %s" % ("AN" if ADDON.getSettingBool("use_inputstream") else "AUS"))
    lines.append("Adaptive bevorzugt: %s" % ("AN" if ADDON.getSettingBool("use_inputstream_adaptive") else "AUS"))
    lines.append("FFmpeg Direct bevorzugt: %s" % ("AN" if ADDON.getSettingBool("use_inputstream_ffmpegdirect") else "AUS"))
    lines.append("Sunshine-Fallback: %s" % ("AN" if ADDON.getSettingBool("allow_sunshine") else "AUS"))
    lines.append("")

    lines.append("=== Netzwerk / Endpunkte ===")
    checks = [
        ("live2 index", "GET", "https://www2.vavoo.to/live2/index?output=json"),
        ("catalog", "POST", "https://vavoo.to/mediahubmx-catalog.json"),
        ("resolver", "POST", "https://vavoo.to/vto-cluster/mediahubmx-resolve.json"),
    ]

    for label, method, url in checks:
        try:
            if method == "GET":
                r = requests.get(url, timeout=get_timeout(6))
            else:
                r = requests.post(url, timeout=get_timeout(6))
            lines.append("%s: HTTP %s" % (label, r.status_code))
        except Exception as e:
            lines.append("%s: FEHLER (%s)" % (label, type(e).__name__))

    lines.append("")
    lines.append("Hinweis: 4xx/5xx kann serverseitig oder DNS/Provider-bedingt sein.")

    xbmcgui.Dialog().textviewer("Smoker Live TV System-Check", "\n".join(lines))


def themed_item(label, icon_name):
    li = xbmcgui.ListItem(label=label)
    icon = ICON_BASE + icon_name
    li.setArt({"icon": icon, "thumb": icon, "poster": icon, "fanart": FANART})
    return li


def main_menu():
    items = [
        ("Live TV", {"mode": "livetv"}, "livetv.png"),
        ("TV Favoriten", {"mode": "tv_favorites"}, "favorites.png"),
        ("Welt TV", {"mode": "welt2"}, "welttv.png"),
        ("System-Check", {"mode": "system_check"}, "system_check.png"),
        ("Länder wählen", {"mode": "choose_countries"}, "countries.png"),
        ("Einstellungen", {"mode": "settings"}, "settings.png"),
    ]

    for label, params, icon_name in items:
        li = themed_item(label, icon_name)
        url = build_url(params)
        is_folder = not params["mode"].startswith(("open_",))
        xbmcplugin.addDirectoryItem(HANDLE, url, li, is_folder)

    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.endOfDirectory(HANDLE)


def route(params):
    mode = params.get("mode") or params.get("action")

    if mode == "tv_favorites":
        import favorites
        favorites.list_favorites()
        return

    if mode == "tv_favorites_add":
        import favorites
        favorites.add_favorite(params.get("source", ""), params.get("name", ""), params.get("url", ""), params.get("logo", ""))
        return

    if mode == "tv_favorites_remove":
        import favorites
        favorites.remove_favorite(params.get("source", ""), params.get("name", ""), params.get("url", ""))
        return

    if mode == "tv_favorites_clear":
        import favorites
        favorites.clear_favorites()
        return

    if mode == "choose_countries":
        choose_countries()
        return

    if mode == "system_check":
        run_system_check()
        return

    if mode == "welt2":
        import vjlive2
        vjlive2.router(params)
        return

    if mode == "welt_menu":
        import vjackson
        vjackson.router({"mode": "countries"})
        return

    if mode == "livetv":
        import vjackson
        vjackson.router({"mode": "livetv"})
        return

    if mode == "channels":
        import vjackson
        vjackson.router({"mode": "channels", "group": params.get("group")})
        return

    if mode == "play":
        import vjackson
        vjackson.router({"mode": "play", "url": params.get("url"), "name": params.get("name")})
        return

    if mode == "settings":
        ADDON.openSettings()
        return

    main_menu()


if __name__ == "__main__":
    args = sys.argv[2][1:]
    params = dict(urllib.parse.parse_qsl(args))
    route(params)
