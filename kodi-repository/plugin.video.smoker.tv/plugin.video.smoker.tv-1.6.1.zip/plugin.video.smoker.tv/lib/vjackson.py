# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
import re
import json
import os
import time
import urllib.parse
import unicodedata

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import utils
import favorites

HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
ADDON = xbmcaddon.Addon()

CATALOG_URL = "https://vavoo.to/vto-cluster/mediahubmx-catalog.json"
RESOLVE_URL = "https://vavoo.to/vto-cluster/mediahubmx-resolve.json"
PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
CATALOG_CACHE_FILE = os.path.join(PROFILE_DIR, "catalog_cache.json")
LOGO_INDEX_FILE = os.path.join(PROFILE_DIR, "logo_index_cache.json")
DEFAULT_CATALOG_CACHE_TTL = 900
DEFAULT_LOGO_CACHE_TTL = 7 * 24 * 60 * 60
RESOLVE_CACHE_TTL = 120
LOGO_CHANNELS_URL = "https://iptv-org.github.io/api/channels.json"
LOGO_LOGOS_URL = "https://iptv-org.github.io/api/logos.json"

groups = {}

THEME_ICON_BASE = "special://home/addons/plugin.video.smoker.tv/resources/media/icons/"
THEME_FANART = "special://home/addons/plugin.video.smoker.tv/fanart_smoker_v2.png"
DEFAULT_CHANNEL_ICON = "special://home/addons/plugin.video.smoker.tv/flags/channel.png"

FLAG_DE_ALL = "special://home/addons/plugin.video.smoker.tv/flags/country/de.png"
FLAG_DE_SKY = "special://home/addons/plugin.video.smoker.tv/flags/country/de_sky.png"
FLAG_DE_SPORT = "special://home/addons/plugin.video.smoker.tv/flags/country/de_sport.png"
FLAG_DE_KINDER = "special://home/addons/plugin.video.smoker.tv/flags/country/de_kinder.png"
FLAG_DE_DOKU = "special://home/addons/plugin.video.smoker.tv/flags/country/de_doku.png"
FLAG_DE_RTL = "special://home/addons/plugin.video.smoker.tv/flags/country/de_rtl.png"
FLAG_DE_P7S1 = "special://home/addons/plugin.video.smoker.tv/flags/country/de_p7s1.png"
FLAG_DE_OEFF = "special://home/addons/plugin.video.smoker.tv/flags/country/de_oeffentlich.png"
FLAG_DE_MUSIK = "special://home/addons/plugin.video.smoker.tv/flags/country/de_musik.png"
FLAG_DE_BACKUP = "special://home/addons/plugin.video.smoker.tv/flags/country/de_backup.png"
FLAG_DE_QUALI = "special://home/addons/plugin.video.smoker.tv/flags/country/de_qualitaet.png"

GROUP_ICONS = {
    "Germany – Alle Sender": FLAG_DE_ALL,
    "Germany – Sky": FLAG_DE_SKY,
    "Germany – Sport": FLAG_DE_SPORT,
    "Germany – Kinder": FLAG_DE_KINDER,
    "Germany – Doku": FLAG_DE_DOKU,
    "Germany – RTL": FLAG_DE_RTL,
    "Germany – ProSiebenSat1": FLAG_DE_P7S1,
    "Germany – Öffentlich‑rechtlich": FLAG_DE_OEFF,
    "Germany – Musik": FLAG_DE_MUSIK,
    "Germany – Backup": FLAG_DE_BACKUP,
    "Germany – Qualität": FLAG_DE_QUALI,
}

LOGO_INDEX = None

MANUAL_LOGO_ALIASES = {
    "ard": ["daserste", "daserste", "ard"],
    "zdf": ["zdf"],
    "zdfneo": ["zdfneo"],
    "zdfinfo": ["zdfinfo"],
    "rtl": ["rtltelevision", "rtl"],
    "rtlzwei": ["rtl2", "rtlii", "rtlzwei"],
    "vox": ["vox"],
    "nitro": ["nitro"],
    "ntv": ["ntv"],
    "prosieben": ["prosieben"],
    "sat1": ["sat1"],
    "kabeleins": ["kabeleins", "kabel1"],
    "sixx": ["sixx"],
    "dmax": ["dmax"],
    "tele5": ["tele5"],
    "welt": ["welt"],
    "3sat": ["3sat"],
    "arte": ["arte"],
    "orf1": ["orf1"],
    "orf2": ["orf2"],
    "servustv": ["servustv"],
    "srf1": ["srf1"],
    "srfzwei": ["srf2", "srfzwei"],
    "kika": ["kika"],
    "superrtl": ["toggo", "superrtl"],
    "nick": ["nickelodeon", "nick"],
    "eurosport1": ["eurosport1", "eurosport"],
    "sport1": ["sport1"],
    "skynews": ["sky"],
    "mtv": ["mtv"],
    "deluxemusic": ["deluxemusic"],
    "mezzolive": ["mezzo"],
}


def _timeout(default=10):
    try:
        value = int(ADDON.getSetting("request_timeout") or default)
        return max(3, min(30, value))
    except Exception:
        return default


def _logos_enabled():
    try:
        return ADDON.getSettingBool("auto_channel_logos")
    except Exception:
        return (ADDON.getSetting("auto_channel_logos") or "true").lower() == "true"


def _logo_cache_ttl():
    try:
        days = int(ADDON.getSetting("logo_cache_days") or 7)
        days = max(1, min(30, days))
        return days * 24 * 60 * 60
    except Exception:
        return DEFAULT_LOGO_CACHE_TTL


def _load_json_cache(path, max_age):
    try:
        if not os.path.exists(path):
            return None
        with open(path, "r", encoding="utf-8") as fh:
            payload = json.load(fh)
        ts = int(payload.get("timestamp") or 0)
        if max_age is not None and ts and (time.time() - ts) > max_age:
            return None
        return payload.get("data")
    except Exception as exc:
        utils.log("JSON-Cache lesen fehlgeschlagen: %s" % exc, xbmc.LOGWARNING)
        return None


def _save_json_cache(path, data):
    try:
        _ensure_profile_dir()
        with open(path, "w", encoding="utf-8") as fh:
            json.dump({"timestamp": int(time.time()), "data": data}, fh)
    except Exception as exc:
        utils.log("JSON-Cache schreiben fehlgeschlagen: %s" % exc, xbmc.LOGWARNING)


def _normalize_logo_name(name):
    value = _normalize_name(name or "")
    value = unicodedata.normalize("NFKD", value)
    value = value.encode("ascii", "ignore").decode("ascii")
    value = value.lower()
    replacements = {
        "&": "and",
        "+": "plus",
        "ii": "zwei",
        "one": "eins",
    }
    for src, dst in replacements.items():
        value = value.replace(src, dst)
    value = re.sub(r"\b(tv|channel|deutschland|germany|osterreich|austria|schweiz|switzerland|hd|fhd|uhd|sd|4k|backup|h265)\b", " ", value)
    value = re.sub(r"[^a-z0-9]+", "", value)
    return value


def _logo_score(entry):
    tags = [str(t).lower() for t in (entry.get("tags") or [])]
    score = 0
    if entry.get("feed") is None:
        score += 4
    if "white" in tags:
        score += 3
    if "horizontal" in tags:
        score += 2
    if str(entry.get("format") or "").upper() == "SVG":
        score += 1
    score += min(int(entry.get("width") or 0), 2000) / 2000.0
    return score


def _build_logo_index():
    global LOGO_INDEX
    if LOGO_INDEX is not None:
        return LOGO_INDEX

    cached = _load_json_cache(LOGO_INDEX_FILE, _logo_cache_ttl())
    if isinstance(cached, dict) and cached:
        LOGO_INDEX = cached
        return LOGO_INDEX

    try:
        channel_resp = requests.get(LOGO_CHANNELS_URL, timeout=_timeout())
        channel_resp.raise_for_status()
        channels = channel_resp.json()

        logo_resp = requests.get(LOGO_LOGOS_URL, timeout=_timeout())
        logo_resp.raise_for_status()
        logos = logo_resp.json()
    except Exception as exc:
        utils.log("Logo-Index konnte nicht geladen werden: %s" % exc, xbmc.LOGWARNING)
        LOGO_INDEX = {}
        return LOGO_INDEX

    wanted_countries = {"DE", "AT", "CH"}
    channel_names = {}
    for channel in channels:
        country = str(channel.get("country") or "").upper()
        if country not in wanted_countries:
            continue
        cid = channel.get("id")
        if not cid:
            continue
        names = set()
        main_name = channel.get("name")
        if main_name:
            names.add(main_name)
        for alt in channel.get("alt_names") or []:
            if alt:
                names.add(alt)
        channel_names[cid] = names

    best_logo_by_channel = {}
    for logo in logos:
        cid = logo.get("channel")
        if cid not in channel_names:
            continue
        current = best_logo_by_channel.get(cid)
        if current is None or _logo_score(logo) > _logo_score(current):
            best_logo_by_channel[cid] = logo

    index = {}
    for cid, names in channel_names.items():
        logo = best_logo_by_channel.get(cid)
        if not logo:
            continue
        url = logo.get("url")
        if not url:
            continue
        for raw_name in names:
            normalized = _normalize_logo_name(raw_name)
            if normalized:
                index[normalized] = url

    for canonical, aliases in MANUAL_LOGO_ALIASES.items():
        url = index.get(canonical)
        if not url:
            continue
        for alias in aliases:
            index[_normalize_logo_name(alias)] = url

    LOGO_INDEX = index
    if index:
        _save_json_cache(LOGO_INDEX_FILE, index)
    return LOGO_INDEX


def _get_logo(name):
    if not _logos_enabled():
        return FLAG_DE_ALL

    cache_key = "logo:" + (name or "")
    cached = utils.get_cache(cache_key)
    if cached:
        return cached

    normalized = _normalize_logo_name(name)
    if not normalized:
        return FLAG_DE_ALL

    cached_index = _load_json_cache(LOGO_INDEX_FILE, _logo_cache_ttl())
    if _fast_channel_loading() and not cached_index:
        utils.set_cache(cache_key, FLAG_DE_ALL, timeout=3600)
        return FLAG_DE_ALL

    index = _build_logo_index()
    logo = index.get(normalized)
    if not logo:
        for alias, alias_logo in index.items():
            if len(alias) < 4:
                continue
            if normalized.startswith(alias) or alias.startswith(normalized):
                logo = alias_logo
                break

    if not logo:
        logo = FLAG_DE_ALL

    utils.set_cache(cache_key, logo, timeout=_logo_cache_ttl())
    return logo




def _fast_channel_loading():
    try:
        return ADDON.getSettingBool("fast_channel_loading")
    except Exception:
        return True

def _catalog_cache_ttl():
    try:
        minutes = int(ADDON.getSetting("catalog_cache_minutes") or 15)
        minutes = max(5, min(120, minutes))
        return minutes * 60
    except Exception:
        return DEFAULT_CATALOG_CACHE_TTL


def _ensure_profile_dir():
    try:
        if not os.path.isdir(PROFILE_DIR):
            os.makedirs(PROFILE_DIR)
    except Exception:
        pass


def _headers():
    return {
        "accept-encoding": "gzip",
        "user-agent": "MediaHubMX/2",
        "accept": "application/json",
        "content-type": "application/json; charset=utf-8",
        "mediahubmx-signature": utils.getAuthSignature(),
    }


def _load_catalog_cache(max_age=None):
    if max_age is None:
        max_age = _catalog_cache_ttl()
    try:
        if not os.path.exists(CATALOG_CACHE_FILE):
            return None
        with open(CATALOG_CACHE_FILE, "r", encoding="utf-8") as fh:
            payload = json.load(fh)
        ts = int(payload.get("timestamp") or 0)
        if max_age is not None and ts and (time.time() - ts) > max_age:
            return None
        cached = payload.get("groups")
        if isinstance(cached, dict) and cached:
            return cached
    except Exception as exc:
        utils.log("Katalog-Cache lesen fehlgeschlagen: %s" % exc, xbmc.LOGWARNING)
    return None


def _save_catalog_cache(data):
    try:
        _ensure_profile_dir()
        with open(CATALOG_CACHE_FILE, "w", encoding="utf-8") as fh:
            json.dump({"timestamp": int(time.time()), "groups": data}, fh)
    except Exception as exc:
        utils.log("Katalog-Cache schreiben fehlgeschlagen: %s" % exc, xbmc.LOGWARNING)


def _get_cached_resolve(url):
    return utils.get_cache("resolve:" + url)


def _set_cached_resolve(url, value):
    utils.set_cache("resolve:" + url, value, timeout=RESOLVE_CACHE_TTL)


def _normalize_name(name):
    return re.sub(r'( (SD|HD|FHD|UHD|H265))?( \(BACKUP\))? \(\d+\)$', '', name)


def _fetch_catalog(force=False):
    global groups

    if groups and not force:
        return True

    if not force:
        cached = _load_catalog_cache()
        if cached:
            groups = cached
            utils.log("Live-TV-Katalog aus lokalem Cache geladen")
            return True

    cursor = 0
    fresh_groups = {}
    try:
        while True:
            payload = {
                "language": "de",
                "region": "AT",
                "catalogId": "vto-iptv",
                "id": "vto-iptv",
                "adult": False,
                "search": "",
                "sort": "name",
                "filter": {},
                "cursor": cursor,
                "clientVersion": "3.0.2",
            }
            r = requests.post(CATALOG_URL, data=json.dumps(payload), headers=_headers(), timeout=_timeout())
            r.raise_for_status()
            data = r.json()
            for item in data.get("items", []):
                group = item.get("group") or "Other"
                name = _normalize_name(item.get("name") or "Unknown")
                fresh_groups.setdefault(group, {}).setdefault(name, []).append(item)
            cursor = data.get("nextCursor")
            if not cursor:
                break

        groups = fresh_groups
        if groups:
            _save_catalog_cache(groups)
        return True
    except Exception as exc:
        fallback = _load_catalog_cache(max_age=365 * 24 * 60 * 60)
        if fallback:
            groups = fallback
            utils.log("Katalogabruf fehlgeschlagen, benutze gespeicherten Cache: %s" % exc, xbmc.LOGWARNING)
            try:
                xbmcgui.Dialog().notification(
                    "Smoker Live TV",
                    "Netzwerkproblem – benutze gespeicherten Live-TV-Katalog.",
                    xbmcgui.NOTIFICATION_WARNING,
                    3500,
                )
            except Exception:
                pass
            return True

        groups = {}
        utils.log("Katalogabruf fehlgeschlagen: %s" % exc, xbmc.LOGERROR)
        try:
            xbmcgui.Dialog().notification(
                "Smoker Live TV",
                "Live-TV-Katalog nicht erreichbar (DNS/Netzwerk/Server).",
                xbmcgui.NOTIFICATION_ERROR,
                5000,
            )
        except Exception:
            pass
        return False


def _resolve(url):
    cached = _get_cached_resolve(url)
    if cached:
        return cached

    payload = {
        "language": "de",
        "region": "AT",
        "url": url,
        "clientVersion": "3.0.2",
    }
    try:
        r = requests.post(RESOLVE_URL, data=json.dumps(payload), headers=_headers(), timeout=_timeout())
        r.raise_for_status()
        data = r.json()
    except Exception as exc:
        utils.log("Stream-Resolve fehlgeschlagen: %s" % exc, xbmc.LOGERROR)
        raise ValueError("Resolver nicht erreichbar")

    if isinstance(data, list) and data:
        stream = data[0].get("url")
        if stream:
            _set_cached_resolve(url, stream)
            return stream
    raise ValueError("Stream konnte nicht aufgelöst werden")


def _url(params):
    return sys.argv[0] + "?" + urllib.parse.urlencode(params)


def _set_theme_art(li, icon, fanart=THEME_FANART):
    li.setArt({"icon": icon, "thumb": icon, "poster": icon, "fanart": fanart})


def _show_groups():
    if not _fetch_catalog():
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    order = [
        "Germany – Alle Sender",
        "Germany – Sky",
        "Germany – Sport",
        "Germany – Kinder",
        "Germany – Doku",
        "Germany – RTL",
        "Germany – ProSiebenSat1",
        "Germany – Öffentlich‑rechtlich",
        "Germany – Musik",
        "Germany – Backup",
        "Germany – Qualität",
    ]
    for g in order:
        li = xbmcgui.ListItem(label=g)
        icon = GROUP_ICONS.get(g) or (THEME_ICON_BASE + "categories.png")
        _set_theme_art(li, icon)
        xbmcplugin.addDirectoryItem(HANDLE, _url({"mode": "channels", "group": g}), li, True)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)


def _match_group(name, group):
    n = name.lower()
    g = group.lower()
    if "alle sender" in g:
        return True
    if "sky" in g and "sky" in n:
        return True
    if "sport" in g and "sport" in n:
        return True
    if "kinder" in g and ("kinder" in n or "kids" in n):
        return True
    if "doku" in g and "doku" in n:
        return True
    if "rtl" in g and "rtl" in n:
        return True
    if "prosiebensat1" in g and ("prosieben" in n or "sat" in n):
        return True
    if "öffentlich" in g and ("ard" in n or "zdf" in n):
        return True
    if "musik" in g and ("musik" in n or "music" in n):
        return True
    if "backup" in g and "backup" in n:
        return True
    if "qualität" in g and ("hd" in n or "fhd" in n or "uhd" in n):
        return True
    return False


def _reconnect_enabled():
    try:
        return ADDON.getSettingBool("auto_reconnect")
    except Exception:
        return True


def _reconnect_attempts():
    try:
        value = int(ADDON.getSetting("reconnect_attempts") or 2)
        return max(1, min(5, value))
    except Exception:
        return 2


def _reconnect_delay():
    try:
        value = int(ADDON.getSetting("reconnect_delay") or 3)
        return max(1, min(10, value))
    except Exception:
        return 3


def _favorite_context(name, url_raw, logo):
    if favorites.is_favorite("livetv", name, url_raw):
        cmd = 'RunPlugin(%s)' % _url({"mode": "tv_favorites_remove", "source": "livetv", "name": name, "url": url_raw})
        return [("Aus TV-Favoriten entfernen", cmd)]

    cmd = 'RunPlugin(%s)' % _url({"mode": "tv_favorites_add", "source": "livetv", "name": name, "url": url_raw, "logo": logo})
    return [("Zu TV-Favoriten hinzufügen", cmd)]


def _build_play_item(stream, name):
    li = xbmcgui.ListItem(label=name, path=stream)
    li.setProperty("IsPlayable", "true")
    _set_theme_art(li, DEFAULT_CHANNEL_ICON)
    _apply_video_info(li, name, '')

    utils.configure_inputstream(li, stream, utils.addon)
    return li


def _resolve_with_retry(url):
    attempts = _reconnect_attempts() if _reconnect_enabled() else 1
    delay = _reconnect_delay()
    last_exc = None

    for attempt in range(1, attempts + 1):
        try:
            return _resolve(url)
        except Exception as exc:
            last_exc = exc
            if attempt >= attempts:
                break
            xbmcgui.Dialog().notification(
                "Smoker Live TV",
                "Verbindung wird erneut versucht (%d/%d)" % (attempt + 1, attempts),
                xbmcgui.NOTIFICATION_WARNING,
                2200,
            )
            xbmc.sleep(delay * 1000)

    raise last_exc or ValueError("Stream konnte nicht aufgelöst werden")


def _apply_video_info(list_item, title, plot=''):

    try:
        tag = list_item.getVideoInfoTag()
        tag.setTitle(title)
        if plot:
            tag.setPlot(plot)
    except Exception:
        list_item.setInfo("video", {"title": title, "plot": plot})


def _show_channels(group):
    if not _fetch_catalog():
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    items = []
    if group.startswith("Germany"):
        for name, lst in groups.get("Germany", {}).items():
            if _match_group(name, group):
                items.extend(lst)
    else:
        for _, lst in groups.get(group, {}).items():
            items.extend(lst)

    for item in items:
        name = item.get("name")
        url_raw = item.get("url")
        logo = _get_logo(name)

        li = xbmcgui.ListItem(label=name)
        _set_theme_art(li, logo or DEFAULT_CHANNEL_ICON)
        li.setProperty("IsPlayable", "true")
        _apply_video_info(li, name, '')
        li.addContextMenuItems(_favorite_context(name, url_raw, logo))

        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url({"mode": "play", "url": url_raw, "name": name}),
            li,
            False,
        )

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)


def _play(url, name):
    try:
        stream = _resolve_with_retry(url)
    except Exception as exc:
        xbmcgui.Dialog().ok("Live TV", "Stream konnte nicht aufgelöst werden.\n\n%s" % exc)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    li = _build_play_item(stream, name)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def router(params):
    mode = (params or {}).get("mode")
    if mode == "livetv":
        _show_groups()
    elif mode == "channels":
        _show_channels(params.get("group") or "Germany – Alle Sender")
    elif mode == "play":
        _play(params.get("url") or "", params.get("name") or "Live TV")
    elif mode == "refresh_catalog":
        if _fetch_catalog(force=True):
            xbmcgui.Dialog().notification("Smoker Live TV", "Live-TV-Katalog wurde aktualisiert.", xbmcgui.NOTIFICATION_INFO, 2500)
        else:
            xbmcgui.Dialog().notification("Smoker Live TV", "Katalog konnte nicht aktualisiert werden.", xbmcgui.NOTIFICATION_ERROR, 3500)
    else:
        _show_groups()
