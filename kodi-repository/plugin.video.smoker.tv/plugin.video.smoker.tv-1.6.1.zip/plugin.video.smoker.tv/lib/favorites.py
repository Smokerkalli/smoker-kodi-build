
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import json
import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE = sys.argv[0]
SETTINGS_KEY = "tv_favorites"
THEME_ICON_BASE = "special://home/addons/plugin.video.smoker.tv/resources/media/icons/"
THEME_FANART = "special://home/addons/plugin.video.smoker.tv/fanart_smoker_v2.png"
DEFAULT_ICON = "special://home/addons/plugin.video.smoker.tv/icon.png"

def build_url(params):
    return BASE + "?" + urllib.parse.urlencode(params)

def _norm(value):
    return (value or "").strip()

def _load():
    raw = ADDON.getSetting(SETTINGS_KEY)
    if not raw:
        return []
    try:
        data = json.loads(raw)
    except Exception:
        return []
    return data if isinstance(data, list) else []

def _save(items):
    ADDON.setSetting(SETTINGS_KEY, json.dumps(items))

def _make(source, name, url="", logo=""):
    return {"source": _norm(source), "name": _norm(name), "url": _norm(url), "logo": _norm(logo)}

def _same(a, b):
    return _norm(a.get("source")) == _norm(b.get("source")) and _norm(a.get("name")) == _norm(b.get("name")) and _norm(a.get("url")) == _norm(b.get("url"))

def is_favorite(source, name, url=""):
    needle = _make(source, name, url)
    for item in _load():
        if _same(item, needle):
            return True
    return False

def add_favorite(source, name, url="", logo=""):
    items = _load()
    entry = _make(source, name, url, logo)
    for item in items:
        if _same(item, entry):
            xbmcgui.Dialog().notification("TV Favoriten", "Bereits vorhanden", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
            return
    items.append(entry)
    items.sort(key=lambda x: (x.get("name") or "").lower())
    _save(items)
    xbmcgui.Dialog().notification("TV Favoriten", "Favorit hinzugefügt", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def remove_favorite(source, name, url=""):
    items = _load()
    needle = _make(source, name, url)
    items = [item for item in items if not _same(item, needle)]
    _save(items)
    xbmcgui.Dialog().notification("TV Favoriten", "Favorit entfernt", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def clear_favorites():
    _save([])
    xbmcgui.Dialog().notification("TV Favoriten", "Alle Favoriten gelöscht", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _play_url(item):
    if item.get("source") == "welt2":
        return build_url({"mode": "welt2", "action": "livePlay", "name": item.get("name", "")})
    return build_url({"mode": "play", "url": item.get("url", ""), "name": item.get("name", "")})

def _apply_art(li, icon):
    li.setArt({"icon": icon, "thumb": icon, "poster": icon, "fanart": THEME_FANART})


def list_favorites():
    items = _load()
    if not items:
        li = xbmcgui.ListItem("Keine TV-Favoriten gespeichert")
        _apply_art(li, THEME_ICON_BASE + "favorites.png")
        xbmcplugin.addDirectoryItem(HANDLE, "", li, False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    clear_li = xbmcgui.ListItem("Favoriten löschen")
    _apply_art(clear_li, THEME_ICON_BASE + "clear.png")
    xbmcplugin.addDirectoryItem(HANDLE, build_url({"mode": "tv_favorites_clear"}), clear_li, False)

    for item in items:
        name = item.get("name") or "Unbekannt"
        logo = item.get("logo") or DEFAULT_ICON
        li = xbmcgui.ListItem(name)
        li.setProperty("IsPlayable", "true")
        _apply_art(li, logo)
        cmd = 'RunPlugin(%s)' % build_url({"mode": "tv_favorites_remove", "source": item.get("source", ""), "name": name, "url": item.get("url", "")})
        li.addContextMenuItems([("Aus TV-Favoriten entfernen", cmd)])
        xbmcplugin.addDirectoryItem(HANDLE, _play_url(item), li, False)

    xbmcplugin.endOfDirectory(HANDLE)
