# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
import os
import json
import time
import requests
import urllib.parse
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

HANDLE = int(sys.argv[1])
SYSADDON = sys.argv[0]
ADDON = xbmcaddon.Addon()
THEME_ICON_BASE = "special://home/addons/plugin.video.smoker.tv/resources/media/icons/"
THEME_FANART = "special://home/addons/plugin.video.smoker.tv/fanart_smoker_v2.png"
DEFAULT_CHANNEL_ICON = "special://home/addons/plugin.video.smoker.tv/flags/channel.png"
CATALOG_URL = "https://vavoo.to/mediahubmx-catalog.json"
INDEX_URL = "https://www2.vavoo.to/live2/index?output=json"
PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
CHANNELS_CACHE_FILE = os.path.join(PROFILE_DIR, "welt_channels_cache.json")
CHANNELS_CACHE = None
SESSION = requests.Session()


def _timeout(default=8):
    try:
        value = int(ADDON.getSetting("request_timeout") or default)
        return max(3, min(30, value))
    except Exception:
        return default


def _cache_ttl():
    try:
        minutes = int(ADDON.getSetting("catalog_cache_minutes") or 15)
        return max(5, min(120, minutes)) * 60
    except Exception:
        return 900


def _fast_channel_loading():
    try:
        return ADDON.getSettingBool("fast_channel_loading")
    except Exception:
        return True


def _ensure_profile_dir():
    try:
        if not os.path.isdir(PROFILE_DIR):
            os.makedirs(PROFILE_DIR)
    except Exception:
        pass


def _selected_groups_key(groups):
    groups = groups or []
    return "|".join(sorted(groups))


def _load_channels_cache(selected_groups, allow_stale=False):
    try:
        if not os.path.exists(CHANNELS_CACHE_FILE):
            return None
        with open(CHANNELS_CACHE_FILE, "r", encoding="utf-8") as fh:
            payload = json.load(fh)
        if payload.get("group_key") != _selected_groups_key(selected_groups):
            return None
        ts = int(payload.get("timestamp") or 0)
        if not allow_stale and ts and (time.time() - ts) > _cache_ttl():
            return None
        data = payload.get("channels")
        if isinstance(data, dict) and data:
            return data
    except Exception:
        pass
    return None


def _save_channels_cache(selected_groups, channels):
    try:
        _ensure_profile_dir()
        with open(CHANNELS_CACHE_FILE, "w", encoding="utf-8") as fh:
            json.dump({
                "timestamp": int(time.time()),
                "group_key": _selected_groups_key(selected_groups),
                "channels": channels,
            }, fh)
    except Exception:
        pass


def build_url(params):
    return SYSADDON + "?" + urllib.parse.urlencode(params)


def normalize_name(raw_name):
    name = (raw_name or "").strip()
    name = re.sub(r"^\[[^\]]+\]\s*", "", name)
    name = re.sub(r"\s+\.[a-z]$", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\s+\((\d+)\)$", "", name)
    return name.strip()


def add_channel_url(chans, name, url):
    if not name or not url:
        return
    if name not in chans:
        chans[name] = []
    if url not in chans[name]:
        chans[name].append(url)


def get_selected_groups():
    raw = ADDON.getSetting("country_groups")
    if not raw:
        return []
    try:
        groups = json.loads(raw)
    except Exception:
        return []
    return groups if isinstance(groups, list) else []


def get_available_groups():
    groups = []
    try:
        data = SESSION.get(INDEX_URL, timeout=_timeout(8)).json()
    except Exception:
        data = []

    for item in data:
        group = item.get("group")
        if group and group not in groups:
            groups.append(group)

    return groups


def choose_countries_popup():
    global CHANNELS_CACHE

    groups = get_available_groups()
    if not groups:
        xbmcgui.Dialog().notification("Fehler", "Keine Gruppen gefunden", xbmcgui.NOTIFICATION_ERROR)
        return

    old = get_selected_groups()
    preselect = [groups.index(group) for group in old if group in groups]

    selected = xbmcgui.Dialog().multiselect("Länder wählen", groups, preselect=preselect)
    if selected is None:
        return

    chosen = [groups[i] for i in selected]
    ADDON.setSetting("country_groups", json.dumps(chosen))
    CHANNELS_CACHE = None

    if chosen:
        msg = "Gruppen gespeichert: %d" % len(chosen)
    else:
        msg = "Alle Gruppen aktiv"
    xbmcgui.Dialog().notification("Welt TV", msg, xbmcgui.NOTIFICATION_INFO)


def load_channels_from_index(chans, selected_groups):
    try:
        data = SESSION.get(INDEX_URL, timeout=_timeout(6)).json()
    except Exception:
        data = []

    for item in data:
        if selected_groups:
            group = item.get("group")
            if group not in selected_groups:
                continue

        name = normalize_name(item.get("name", ""))
        add_channel_url(chans, name, item.get("url"))


def load_channels_from_catalog(chans, selected_groups):
    headers = {
        "user-agent": "okhttp/4.11.0",
        "accept": "application/json",
        "content-type": "application/json; charset=utf-8",
        "accept-encoding": "gzip"
    }

    group_filters = selected_groups if selected_groups else [None]

    for group_filter in group_filters:
        cursor = 0
        while cursor is not None:
            payload = {
                "language": "de",
                "region": "AT",
                "catalogId": "iptv",
                "id": "iptv",
                "adult": False,
                "search": "",
                "sort": "name",
                "filter": {"group": group_filter} if group_filter else {},
                "cursor": cursor,
                "clientVersion": "3.0.2"
            }

            try:
                response = SESSION.post(CATALOG_URL, json=payload, headers=headers, timeout=_timeout(8))
                data = response.json()
            except Exception:
                break

            for item in data.get("items", []):
                if selected_groups:
                    item_group = item.get("group")
                    if item_group not in selected_groups:
                        continue

                name = normalize_name(item.get("name", ""))
                add_channel_url(chans, name, item.get("url"))

            cursor = data.get("nextCursor")


def load_channels():
    global CHANNELS_CACHE
    if CHANNELS_CACHE is not None:
        return CHANNELS_CACHE

    selected_groups = get_selected_groups()

    cached = _load_channels_cache(selected_groups)
    if cached:
        CHANNELS_CACHE = cached
        return CHANNELS_CACHE

    chans = {}
    load_channels_from_index(chans, selected_groups)
    load_channels_from_catalog(chans, selected_groups)

    if chans:
        _save_channels_cache(selected_groups, chans)
        CHANNELS_CACHE = chans
        return CHANNELS_CACHE

    fallback = _load_channels_cache(selected_groups, allow_stale=True)
    if fallback:
        CHANNELS_CACHE = fallback
        return CHANNELS_CACHE

    CHANNELS_CACHE = chans
    return CHANNELS_CACHE


def resolve_link(link):
    headers = {
        "user-agent": "MediaHubMX/2",
        "accept": "application/json",
        "content-type": "application/json; charset=utf-8",
        "accept-encoding": "gzip"
    }

    payload = {
        "language": "de",
        "region": "AT",
        "url": link,
        "clientVersion": "3.0.2"
    }

    try:
        response = SESSION.post(
            "https://vavoo.to/vto-cluster/mediahubmx-resolve.json",
            data=json.dumps(payload),
            headers=headers,
            timeout=_timeout(8)
        ).json()

        if isinstance(response, list) and response:
            return response[0].get("url", link)
        if isinstance(response, dict):
            return response.get("url", link)
        return link
    except Exception:
        return link


def apply_playback_properties(list_item, stream_url):
    utils.configure_inputstream(list_item, stream_url, ADDON)


def is_sunshine_url(url):
    return "/vavoo-iptv/" in (url or "")


def url_reachable(url):
    try:
        response = SESSION.get(url, timeout=4, allow_redirects=True, stream=True)
        ok = response.status_code in (200, 206)
        response.close()
        return ok
    except Exception:
        return False


def live2_variants(url):
    variants = []
    if "live2/play3/" in (url or ""):
        for n in ("1", "2", "4"):
            variants.append(url.replace("/play3/", "/play%s/" % n))
    return variants


def build_candidates(raw_url):
    candidates = []

    if is_sunshine_url(raw_url):
        candidates.append(raw_url)
        return candidates

    resolved = resolve_link(raw_url)
    if resolved:
        candidates.append(resolved)

    candidates.append(raw_url)
    candidates.extend(live2_variants(raw_url))

    unique = []
    for candidate in candidates:
        if candidate and candidate not in unique:
            unique.append(candidate)
    return unique


def choose_best_stream(streams):
    allow_sunshine = ADDON.getSettingBool("allow_sunshine")
    nonsunshine = [s for s in streams if not is_sunshine_url(s)]
    sunshine = [s for s in streams if is_sunshine_url(s)] if allow_sunshine else []
    ordered = nonsunshine + sunshine

    if _fast_channel_loading():
        for raw in ordered:
            candidates = build_candidates(raw)
            if candidates:
                return candidates[0]
        return None

    for raw in ordered:
        for candidate in build_candidates(raw):
            if url_reachable(candidate):
                return candidate

    if ordered:
        candidates = build_candidates(ordered[0])
        if candidates:
            return candidates[0]
    return None


def livePlay(name):
    chans = load_channels()

    if name not in chans:
        xbmcgui.Dialog().ok("Fehler", "Kein Stream gefunden.")
        return

    streams = chans[name]

    stream_select_mode = ADDON.getSetting("stream_select")
    manual_select = stream_select_mode == "0"
    auto_try_next = ADDON.getSettingBool("auto_try_next_stream")

    if len(streams) == 1:
        chosen_streams = [streams[0]]
    elif manual_select:
        labels = ["Stream %s" % (i + 1) for i in range(len(streams))]
        idx = xbmcgui.Dialog().select("Stream auswählen", labels)
        if idx < 0:
            return

        if auto_try_next:
            chosen_streams = [streams[idx]] + [s for i, s in enumerate(streams) if i != idx]
        else:
            chosen_streams = [streams[idx]]
    else:
        chosen_streams = list(streams) if auto_try_next else [streams[0]]

    url = choose_best_stream(chosen_streams)

    if not url:
        xbmcgui.Dialog().ok("Fehler", "Kein funktionierender Stream gefunden.")
        return

    li = xbmcgui.ListItem(name)
    _apply_art(li, DEFAULT_CHANNEL_ICON)
    li.setPath(url)
    li.setProperty("IsPlayable", "true")
    apply_playback_properties(li, url)

    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def _apply_art(li, icon):
    li.setArt({"icon": icon, "thumb": icon, "poster": icon, "fanart": THEME_FANART})


def channels():
    chans = load_channels()

    for name in sorted(chans.keys()):
        li = xbmcgui.ListItem(name)
        li.setProperty("IsPlayable", "true")
        li.setArt({"icon": DEFAULT_CHANNEL_ICON, "thumb": DEFAULT_CHANNEL_ICON, "poster": DEFAULT_CHANNEL_ICON, "fanart": THEME_FANART})

        url = build_url({
            "mode": "welt2",
            "action": "livePlay",
            "name": name
        })

        xbmcplugin.addDirectoryItem(HANDLE, url, li, False)

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)


def a_z_tv():
    channels()


def router(params):
    action = params.get("action") or params.get("mode")
    if action == "choose_countries":
        choose_countries_popup()
    elif action == "livePlay":
        livePlay(params.get("name", ""))
    elif action in ("channels", "welt2", "a_z_tv"):
        channels()
    else:
        channels()
