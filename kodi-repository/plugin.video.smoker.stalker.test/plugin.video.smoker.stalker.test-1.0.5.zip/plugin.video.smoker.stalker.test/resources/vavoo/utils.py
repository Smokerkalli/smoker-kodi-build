# -*- coding: utf-8 -*-
import json
import os
import random
import string
import sys
import time
from datetime import datetime
from hashlib import md5, sha1, sha256
from traceback import format_exc
from urllib.parse import quote, urlencode, urlparse, urlsplit

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from dateutil.parser import parse
from xbmcgui import Dialog, DialogProgress, ListItem, Window
from infotagger.listitem import ListItemInfoTag


addon = xbmcaddon.Addon("plugin.video.smoker.stalker.test")
addonInfo = addon.getAddonInfo
addonID = "plugin.video.smoker.stalker.test"
addonprofile = xbmcvfs.translatePath(addonInfo("profile"))
cachepath = os.path.join(addonprofile, "cache")
if not os.path.exists(cachepath):
	os.makedirs(cachepath)

home = Window(10000)
progress = DialogProgress()
dialog = Dialog()
monitor = xbmc.Monitor()
getSetting = addon.getSetting
setSetting = addon.setSetting
openSettings = addon.openSettings
execute = xbmc.executebuiltin


def log(message, header=""):
	prefix = "[%s]" % (header or addonInfo("name"))
	xbmc.log("%s %s" % (prefix, message), xbmc.LOGINFO)


def _cache_key(key):
	return urlencode({"key": key})[4:]


def set_cache(key, value, timeout=False):
	path = _cache_key(key)
	expires = False if timeout is False else int(time.time()) + (timeout * 3600)
	data = json.dumps({"sigValidUntil": expires, "value": value})
	home.setProperty(path, data)
	with open(os.path.join(cachepath, path), "w", encoding="utf-8") as cache_file:
		cache_file.write(data)


def get_cache(key):
	path = _cache_key(key)
	data = home.getProperty(path)
	if not data:
		file_path = os.path.join(cachepath, path)
		if not os.path.isfile(file_path):
			return False, None
		try:
			with open(file_path, "r", encoding="utf-8") as cache_file:
				data = cache_file.read()
		except:
			return False, None
	try:
		entry = json.loads(data)
	except:
		return False, None
	expires = entry.get("sigValidUntil", 0)
	if expires is False or expires > int(time.time()):
		home.setProperty(path, data)
		return True, entry.get("value")
	del_cache(key)
	return False, None


def get_cache_or_setting(setting):
	cache_ok, value = get_cache(setting)
	if not cache_ok:
		value = getSetting(setting)
		set_cache(setting, value)
	return value


def del_cache(key):
	path = _cache_key(key)
	home.clearProperty(path)
	try:
		os.remove(os.path.join(cachepath, path))
	except OSError:
		pass


def selectDialog(items, heading=None, multiselect=False, preselect=False):
	heading = addonInfo("name") if heading is None else heading
	if multiselect:
		return dialog.multiselect(str(heading), items, preselect=[] if preselect is False else preselect)
	return dialog.select(str(heading), items, preselect=preselect)


def filterout(name):
	return name.strip()


def showFailedNotification(message="Keine Streams gefunden"):
	log(message)
	dialog.notification(addonInfo("name"), message, xbmcgui.NOTIFICATION_ERROR, 5000)


def url_for(params):
	clean = {key: value for key, value in params.items() if value is not None}
	return "%s?%s" % (sys.argv[0], urlencode(clean))


def add(params, item, isFolder=False):
	return xbmcplugin.addDirectoryItem(int(sys.argv[1]), url_for(params), item, isFolder)


def addDir(name, params, iconimage="DefaultFolder.png", isFolder=True, context=None):
	item = ListItem(name)
	item.setArt({"icon": iconimage, "thumb": iconimage})
	menu = list(context or [])
	menu.append(("Einstellungen", "RunPlugin(%s?action=settings)" % sys.argv[0]))
	item.addContextMenuItems(menu)
	ListItemInfoTag(item, "video").set_info({"title": name, "plot": " "})
	add(params, item, isFolder)


def addDir2(name, icon, action, context=None, isFolder=True, **params):
	params["action"] = action
	addDir(name, params, icon, isFolder, context)


def set_content(content):
	xbmcplugin.setContent(int(sys.argv[1]), content)


def set_resolved(item):
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def sort_method():
	xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_TITLE)


def end(succeeded=True, cacheToDisc=True):
	return xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=succeeded, cacheToDisc=cacheToDisc)
