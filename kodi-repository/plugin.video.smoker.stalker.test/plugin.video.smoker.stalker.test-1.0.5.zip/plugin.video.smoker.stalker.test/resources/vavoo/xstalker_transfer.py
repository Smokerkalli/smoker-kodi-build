# -*- coding: utf-8 -*-
import os
from urllib.parse import urlsplit

import xbmcaddon
import xbmcgui
import xbmcvfs

from vavoo.utils import addonInfo, dialog, getSetting, log


TARGET_ADDON_ID = "plugin.video.smoker.xstalker"
MAX_PORTALS = 10


def _suffix(slot):
	return "" if slot == 1 else "_%s" % slot


def _first_free_slot(target):
	for slot in range(1, MAX_PORTALS + 1):
		suffix = _suffix(slot)
		server = (target.getSetting("server_address%s" % suffix) or "").strip()
		mac = (target.getSetting("mac_address%s" % suffix) or "").strip()
		if not server and not mac:
			return slot
	return None


def _clear_quickstart_cache(target):
	profile = xbmcvfs.translatePath(target.getAddonInfo("profile"))
	cache_file = os.path.join(profile, "quickstart_cache.json")
	if xbmcvfs.exists(cache_file):
		xbmcvfs.delete(cache_file)


def export_selected_portal():
	portal = (getSetting("stalkerurl") or "").strip()
	mac = (getSetting("mac") or "").strip()
	if not portal or not mac:
		dialog.ok(addonInfo("name"), "Bitte zuerst ein Stalker-Portal und eine MAC-Adresse auswählen.")
		return

	try:
		target = xbmcaddon.Addon(TARGET_ADDON_ID)
	except Exception:
		dialog.ok(addonInfo("name"), "Smoker XStalker ist nicht installiert.")
		return

	slot = _first_free_slot(target)
	if slot is None:
		dialog.ok(addonInfo("name"), "In Smoker XStalker ist kein freier Portalplatz vorhanden.")
		return

	message = "Portal:\n%s\n\nMAC:\n%s\n\nIn freien XStalker-Platz %s übertragen?" % (portal, mac, slot)
	if not dialog.yesno(addonInfo("name"), message, nolabel="Abbrechen", yeslabel="Übertragen"):
		return

	suffix = _suffix(slot)
	host = urlsplit(portal).hostname or "Portal"
	target.setSetting("server_address%s" % suffix, portal)
	target.setSetting("mac_address%s" % suffix, mac)
	target.setSetting("portal_name%s" % suffix, "Smokers Portale - %s" % host)
	target.setSetting("portal_error%s" % suffix, "false")
	target.setSetting("portal_status_state%s" % suffix, "unknown")
	target.setSetting("portal_status_summary%s" % suffix, "Neu aus Smokers Portale übertragen")
	target.setSetting("portal_last_handshake%s" % suffix, "")
	target.setSetting("portal_last_ping%s" % suffix, "")
	_clear_quickstart_cache(target)
	log("Portal in Smoker XStalker Platz %s übertragen" % slot)
	dialog.notification(addonInfo("name"), "Portal wurde in XStalker-Platz %s übertragen." % slot, xbmcgui.NOTIFICATION_INFO, 5000)
