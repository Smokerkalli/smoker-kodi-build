# -*- coding: utf-8 -*-
from vavoo.utils import *
from vavoo.stalker import StalkerPortal, get_genres, new_mac


def _portal():
	return StalkerPortal(get_cache_or_setting("stalkerurl"), get_cache_or_setting("mac"))


def _channels(group=None):
	if group is None:
		cache_ok, genres = get_cache("stalker_groups")
		if not cache_ok or not genres:
			genres = get_genres()
	else:
		genres = [group]
	if not genres:
		return {}

	cache_ok, raw_channels = get_cache("sta_channels")
	if not cache_ok:
		portal = _portal()
		check = portal.check()
		if check is not True:
			if check != "IP BLOCKED":
				new_mac(True)
			cache_ok, raw_channels = get_cache("sta_channels")
			if not cache_ok:
				return {}

	result = {}
	for item in raw_channels:
		if item["tv_genre_id"] not in genres:
			continue
		name = item["name"].upper()
		if any(marker in name for marker in ("***", "###", "---")):
			continue
		name = filterout(name)
		if not name:
			continue
		result.setdefault(name, [])
		if item["cmd"] not in result[name]:
			result[name].append(item["cmd"])
	return result


def groups():
	set_content("files")
	for title, group_id in _portal().genres().items():
		label = title.encode().decode("ascii", errors="ignore")
		addDir2(label, "DefaultAddonPVRClient", "channels", group=group_id)
	end()


def channels(group=None):
	set_content("videos")
	for name in _channels(group):
		item = ListItem(name)
		item.setProperty("IsPlayable", "true")
		info_tag = ListItemInfoTag(item, "video")
		info_tag.set_info({"title": name})
		add({"name": name, "group": group} if group else {"name": name}, item)
	sort_method()
	end()


def _resolve(command):
	try:
		url, headers = _portal().get_tv_stream_url(command)
		if not url:
			return None, None
		response = requests.get(url, headers=headers, timeout=10, stream=True)
		if response.status_code < 400:
			encoded_headers = "&".join(["%s=%s" % (key, value) for key, value in headers.items()])
			return url, encoded_headers
	except:
		log(format_exc())
	return None, None


def play(name, group=None):
	streams = _channels(group).get(name, [])
	for command in streams:
		url, headers = _resolve(command)
		if not url:
			continue
		item = ListItem(name)
		item.setProperty("inputstream", "inputstream.ffmpegdirect")
		item.setProperty("inputstream.ffmpegdirect.is_realtime_stream", "true")
		item.setProperty("inputstream.ffmpegdirect.stream_mode", "timeshift")
		if "hls" in url or "m3u8" in url:
			item.setProperty("inputstream.ffmpegdirect.manifest_type", "hls")
		if headers:
			url += "|" + headers
		item.setPath(url)
		item.setProperty("IsPlayable", "true")
		ListItemInfoTag(item, "video").set_info({"title": name})
		set_resolved(item)
		end()
		return
	showFailedNotification()
