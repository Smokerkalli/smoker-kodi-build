# -*- coding: utf-8 -*-
import sys
from urllib.parse import parse_qsl

from vavoo.utils import *
from vavoo import stalker, stalker_live, xstalker_transfer


def root_menu():
	set_content("files")
	addDir2("STALKER - SENDER", "DefaultAddonPVRClient", "channels")
	addDir2("STALKER - GRUPPEN", "DefaultAddonPVRClient", "groups")
	addDir2("STALKER Portal Auswahl", "DefaultAddonPVRClient", "choose_portal", isFolder=False)
	addDir2("Neue Mac Adresse", "DefaultAddonPVRClient", "new_mac", isFolder=False)
	addDir2("STALKER Kanalgruppen Auswahl", "DefaultAddonPVRClient", "get_genres", isFolder=False)
	addDir2("STALKER Einstellungen", "DefaultAddonSettings", "settings", isFolder=False)
	end()


if __name__ == "__main__":
	params = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
	action = params.get("action")
	name = params.get("name")
	if name:
		stalker_live.play(name, params.get("group"))
	elif action is None:
		root_menu()
	elif action == "channels":
		stalker_live.channels(params.get("group"))
	elif action == "groups":
		stalker_live.groups()
	elif action == "get_genres":
		stalker.get_genres()
	elif action == "choose_portal":
		stalker.choose_portal()
	elif action == "new_mac":
		stalker.new_mac()
	elif action == "settings":
		openSettings()
	elif action == "export_xstalker":
		xstalker_transfer.export_selected_portal()
