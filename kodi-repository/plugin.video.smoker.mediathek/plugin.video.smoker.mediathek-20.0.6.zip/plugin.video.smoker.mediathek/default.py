# -*- coding: utf-8 -*-
import os
import json
import sys
import time
from collections import deque
from urllib.parse import parse_qsl, urlencode, quote_plus, unquote_plus

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

try:
    import xbmcvfs
except Exception:
    xbmcvfs = None

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE = sys.argv[0]
ADDON_NAME = ADDON.getAddonInfo("name")
PROFILE = ADDON.getAddonInfo("profile")
FANART = "resources/media/fanart.jpg"
ICON = "resources/media/icon.png"

REPO_ID = "repository.kodinerds"
REPO_URL = "https://repo.kodinerds.net/addons/repository.kodinerds/repository.kodinerds-7.0.1.7.zip"

MAX_HISTORY = 40
INDEX_VERSION = 6
INDEX_DEFAULT_MAX_DIRS = 120
INDEX_DEFAULT_MAX_ITEMS = 2000
INDEX_DEFAULT_DEPTH = 3

SOURCES = {
    "HGTV": {
        "path": "plugin://plugin.video.discovery.hgtv/",
        "art": "resources/media/hgtv.jpg",
        "id": "plugin.video.discovery.hgtv",
        "desc": "Home, Renovierung und Immobilien.",
        "indexable": False,
    },
    "TLC": {
        "path": "plugin://plugin.video.discovery.tlc/",
        "art": "resources/media/tlc.jpg",
        "id": "plugin.video.discovery.tlc",
        "desc": "Reality, Doku und Entertainment.",
        "indexable": False,
    },
    "RTL+": {
        "path": "plugin://plugin.video.tvnow.de/",
        "art": "resources/media/rtl.jpg",
        "id": "plugin.video.tvnow.de",
        "desc": "Shows, Serien und Specials von RTL+.",
        "indexable": True,
    },
}


def mkurl(q):
    return BASE + "?" + urlencode(q)


def notify(msg, icon=xbmcgui.NOTIFICATION_INFO):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, icon, 3500)


def log(msg, level=xbmc.LOGINFO):
    try:
        if addon_setting_bool("debug", False):
            xbmc.log("[%s] %s" % (ADDON_NAME, msg), level)
    except Exception:
        pass


def has_addon(addon_id):
    return xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id)


def addon_setting_bool(key, default=False):
    try:
        return ADDON.getSettingBool(key)
    except Exception:
        val = ADDON.getSetting(key)
        return val.lower() == "true" if val else default


def addon_setting_int(key, default=0):
    try:
        return ADDON.getSettingInt(key)
    except Exception:
        try:
            return int(ADDON.getSetting(key))
        except Exception:
            return default


def quality_label():
    values = ["Auto", "1080p", "720p", "480p"]
    idx = addon_setting_int("quality", 0)
    return values[idx] if 0 <= idx < len(values) else "Auto"


def ensure_profile():
    try:
        p = xbmcvfs.translatePath(PROFILE) if xbmcvfs else PROFILE
    except Exception:
        p = PROFILE
    if xbmcvfs:
        if not xbmcvfs.exists(p):
            xbmcvfs.mkdirs(p)
    elif not os.path.exists(p):
        os.makedirs(p)
    return p


def data_path(name):
    return os.path.join(ensure_profile(), name)


def read_json(name, default):
    try:
        with open(data_path(name), "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, type(default)) else default
    except Exception:
        return default


def write_json(name, data):
    with open(data_path(name), "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def fav_file():
    return data_path("favorites.json")


def load_favs():
    return read_json("favorites.json", [])


def save_favs(data):
    write_json("favorites.json", data)


def load_history():
    return read_json("history.json", [])


def save_history(data):
    write_json("history.json", data)


def load_searches():
    return []


def save_searches(data):
    return


def is_fav(path):
    return any(x.get("path") == path for x in load_favs())


def add_fav(src, label, path, is_folder, art="", plot=""):
    items = load_favs()
    if is_fav(path):
        notify("Bereits in Favoriten")
        return
    items.append({
        "source": src,
        "label": label,
        "path": path,
        "folder": is_folder,
        "art": art,
        "plot": plot,
        "added": int(time.time()),
    })
    save_favs(items)
    notify("Favorit gespeichert")


def remove_fav(path):
    save_favs([x for x in load_favs() if x.get("path") != path])
    notify("Favorit entfernt")


def add_history(src, label, path, is_folder, art="", plot=""):
    items = [x for x in load_history() if x.get("path") != path]
    items.insert(0, {
        "source": src,
        "label": label,
        "path": path,
        "folder": is_folder,
        "art": art,
        "plot": plot,
        "added": int(time.time()),
    })
    save_history(items[:MAX_HISTORY])


def clear_history():
    save_history([])
    notify("Verlauf geleert")


def add_search_term(term):
    return


def clear_searches():
    return


def art_for_source(src):
    return SOURCES.get(src, {}).get("art", FANART)


def set_art(li, art):
    use_art = art if art else FANART
    li.setArt({
        "thumb": use_art,
        "icon": use_art,
        "poster": use_art,
        "banner": use_art,
        "landscape": use_art,
        "fanart": FANART,
    })


def list_item(label, art="", plot="", playable=False):
    li = xbmcgui.ListItem(label)
    set_art(li, art)
    try:
        li.setInfo("video", {"title": label, "plot": plot, "mediatype": "video"})
    except Exception:
        pass
    if playable:
        li.setProperty("IsPlayable", "true")
    return li


def add_directory_item(label, action, folder=False, context=None, art="", plot="", playable=False):
    li = list_item(label, art, plot, playable)
    if context:
        li.addContextMenuItems(context)
    xbmcplugin.addDirectoryItem(HANDLE, mkurl({"action": action}), li, folder)


def end_dir(sort=False):
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    if sort:
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_DATEADDED)
    xbmcplugin.endOfDirectory(HANDLE)


def source_state(src):
    meta = SOURCES[src]
    return "[COLOR lime]Installiert[/COLOR]" if has_addon(meta["id"]) else "[COLOR red]Fehlt[/COLOR]"


def jsonrpc(method, params):
    payload = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})
    raw = xbmc.executeJSONRPC(payload)
    try:
        return json.loads(raw)
    except Exception:
        return {}


def get_dir(path):
    res = jsonrpc("Files.GetDirectory", {
        "directory": path,
        "media": "video",
        "properties": ["title", "plot", "art", "thumbnail", "playcount", "file"],
    })
    if "error" in res:
        log("JSONRPC error on path %s: %s" % (path, res.get("error")), xbmc.LOGERROR)
    return res.get("result", {}).get("files", [])


def install_repo():
    try:
        try:
            addons_dir = xbmc.translatePath("special://home/addons/")
        except Exception:
            addons_dir = xbmcvfs.translatePath("special://home/addons/")
        notify("Installiere Kodinerds Repo")
        xbmc.executebuiltin("Extract(%s,%s)" % (REPO_URL, addons_dir))
        xbmc.sleep(2500)
        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.executebuiltin("EnableAddon(%s)" % REPO_ID)
        notify("Repo installiert")
    except Exception as e:
        log("Repo installation failed: %s" % e, xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Fehler", "Repo Installation fehlgeschlagen")


def ensure_repo():
    if not has_addon(REPO_ID):
        install_repo()


def collect_search_items():
    items = []
    for f in load_favs():
        data = dict(f)
        data["origin"] = "Favoriten"
        items.append(data)
    for h in load_history():
        if not any(x.get("path") == h.get("path") for x in items):
            data = dict(h)
            data["origin"] = "Verlauf"
            items.append(data)
    return items


def normalized_text(text):
    return (text or "").strip().lower()


def index_file():
    return data_path("global_index.json")


def load_index_payload():
    return read_json("global_index.json", {"version": INDEX_VERSION, "updated": 0, "items": [], "stats": {}})


def save_index_payload(payload):
    write_json("global_index.json", payload)


def index_stats_text():
    payload = load_index_payload()
    items = payload.get("items", [])
    updated = int(payload.get("updated", 0) or 0)
    stamp = time.strftime("%d.%m.%Y %H:%M", time.localtime(updated)) if updated else "noch nie"
    per_src = payload.get("stats", {}).get("per_source", {})
    parts = []
    for src, meta in SOURCES.items():
        if not meta.get("indexable", True):
            continue
        if per_src.get(src):
            parts.append("%s: %d" % (src, per_src.get(src, 0)))
    return "Index: %d Einträge\nZuletzt aktualisiert: %s\n%s" % (
        len(items), stamp, " | ".join(parts) if parts else "Noch keine Quellen indiziert"
    )


def dedupe_items(items):
    seen = set()
    out = []
    for item in items:
        key = (item.get("path"), item.get("source"), item.get("label") or item.get("title"))
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    return out


def crawl_source(src, root_path, progress=None, max_dirs=INDEX_DEFAULT_MAX_DIRS, max_items=INDEX_DEFAULT_MAX_ITEMS, max_depth=INDEX_DEFAULT_DEPTH):
    queue = deque([(root_path, 0)])
    visited_dirs = set()
    playable = []
    file_seen = set()
    dir_counter = 0

    while queue and dir_counter < max_dirs and len(playable) < max_items:
        if progress and progress.iscanceled():
            raise RuntimeError("cancelled")
        current_path, depth = queue.popleft()
        if current_path in visited_dirs:
            continue
        visited_dirs.add(current_path)
        dir_counter += 1

        if progress:
            progress.update(min(99, int((dir_counter / float(max_dirs or 1)) * 100)), "%s\n%s" % (src, current_path))
        try:
            entries = get_dir(current_path)
        except Exception as e:
            log("crawl get_dir failed for %s: %s" % (current_path, e), xbmc.LOGERROR)
            continue

        for entry in entries:
            label = entry.get("label") or entry.get("title") or ""
            entry_path = entry.get("file", "")
            entry_type = entry.get("filetype", "file")
            if not entry_path or not label:
                continue
            art = ""
            if isinstance(entry.get("art"), dict):
                art = entry["art"].get("poster") or entry["art"].get("thumb") or entry["art"].get("icon") or ""
            art = art or entry.get("thumbnail", "") or art_for_source(src)
            plot = entry.get("plot", "")

            if entry_type == "directory":
                if depth < max_depth:
                    queue.append((entry_path, depth + 1))
                continue

            key = (entry_path, label)
            if key in file_seen:
                continue
            file_seen.add(key)
            playable.append({
                "source": src,
                "label": label,
                "title": label,
                "path": entry_path,
                "folder": False,
                "art": art,
                "plot": plot,
                "indexed_from": current_path,
            })
            if len(playable) >= max_items:
                break

    return {"items": playable, "dirs": len(visited_dirs)}


def build_global_index():
    index_path = os.path.join(PROFILE, "global_index.json")
    try:
        if os.path.exists(index_path):
            age = time.time() - os.path.getmtime(index_path)
            if age < 86400:
                xbmc.log("Mediatheken AIO: using cached index", xbmc.LOGINFO)
                xbmcgui.Dialog().notification(ADDON_NAME, "Index bereits aktuell (Cache)", xbmcgui.NOTIFICATION_INFO, 3000)
                return
    except Exception:
        pass

    payload = {"version": INDEX_VERSION, "updated": 0, "items": [], "stats": {"per_source": {}, "dirs": {}}}
    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "Globalen Suchindex baue auf (RTL+) ...")
    try:
        installed_sources = [
            (src, meta) for src, meta in SOURCES.items()
            if meta.get("indexable", True)
        ]
        all_items = []
        working_sources = 0
        total = len(installed_sources) or 1
        for pos, (src, meta) in enumerate(installed_sources, 1):
            if progress.iscanceled():
                raise RuntimeError("cancelled")
            progress.update(int(((pos - 1) / float(total)) * 100), "Indiziere %s\n%s" % (src, meta["path"]))
            try:
                result = crawl_source(src, meta["path"], progress=progress)
                items = result.get("items", [])
                dirs = result.get("dirs", 0)
                payload["stats"]["per_source"][src] = len(items)
                payload["stats"]["dirs"][src] = dirs
                if items or dirs:
                    working_sources += 1
                all_items.extend(items)
            except RuntimeError:
                raise
            except Exception as e:
                log("Indexing failed for %s: %s" % (src, e), xbmc.LOGERROR)
                payload["stats"]["per_source"][src] = 0
                payload["stats"]["dirs"][src] = 0

        if working_sources == 0:
            progress.close()
            notify("Keine indexierbare Quelle erreichbar (RTL+)", xbmcgui.NOTIFICATION_WARNING)
            return False

        payload["items"] = dedupe_items(all_items)
        payload["updated"] = int(time.time())
        save_index_payload(payload)
        progress.update(100, "Fertig\n%d Einträge gespeichert" % len(payload["items"]))
        progress.close()
        notify("Suchindex erstellt: %d Einträge" % len(payload["items"]))
        return True
    except RuntimeError:
        progress.close()
        notify("Indexaufbau abgebrochen", xbmcgui.NOTIFICATION_WARNING)
        return False
    except Exception as e:
        progress.close()
        log("build_global_index failed: %s" % e, xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Fehler", "Index konnte nicht erstellt werden.", str(e))
        return False


def ensure_index():
    payload = load_index_payload()
    if payload.get("version") != INDEX_VERSION or not payload.get("items"):
        return build_global_index()
    return True


def score_match(item, query):
    q = normalized_text(query)
    title = normalized_text(item.get("label") or item.get("title"))
    plot = normalized_text(item.get("plot"))
    source = normalized_text(item.get("source"))
    if not q:
        return -1
    if title == q:
        return 100
    if title.startswith(q):
        return 80
    if q in title:
        return 60
    if q in plot:
        return 30
    if q in source:
        return 20
    return -1


def run_search(term):
    xbmcplugin.setPluginCategory(HANDLE, "Suche: %s" % term)
    xbmcplugin.setContent(HANDLE, "videos")
    query = normalized_text(term)
    if not query:
        add_directory_item("Leerer Suchbegriff", "noop", False, art=ICON)
        end_dir()
        return

    add_search_term(term)
    ensure_index()
    payload = load_index_payload()
    global_matches = []
    for item in payload.get("items", []):
        score = score_match(item, query)
        if score >= 0:
            hit = dict(item)
            hit["score"] = score
            hit["origin"] = "Index"
            global_matches.append(hit)

    local_matches = []
    for item in collect_search_items():
        hay = " ".join([item.get("label", ""), item.get("source", ""), item.get("plot", "")]).lower()
        if query in hay:
            hit = dict(item)
            hit["score"] = 40
            hit["origin"] = hit.get("origin", "Lokal")
            local_matches.append(hit)

    merged = dedupe_items(sorted(global_matches + local_matches, key=lambda x: (-x.get("score", 0), x.get("label", "").lower())))
    if not merged:
        add_directory_item("Keine Treffer für: %s" % term, "noop", False, art=ICON,
                           plot="Keine Treffer im globalen Index, in Favoriten oder im Verlauf.")
        end_dir()
        return

    for item in merged:
        label = item.get("label") or item.get("title") or ""
        art = item.get("art") or art_for_source(item.get("source", ""))
        plot = item.get("plot", "")
        src = item.get("source", "")
        origin = item.get("origin", "Treffer")
        display = "%s [COLOR gray](%s · %s)[/COLOR]" % (label, src, origin)
        ctx = []
        if is_fav(item.get("path", "")):
            ctx.append(("Aus Favoriten entfernen", "RunPlugin(%s)" % mkurl({"action": "removefav", "path": item["path"]})))
        else:
            ctx.append(("Zu Favoriten hinzufügen", "RunPlugin(%s)" % mkurl({
                "action": "addfav", "src": src, "label": label, "path": item["path"],
                "folder": "0", "art": art, "plot": plot,
            })))
        add_directory_item(display,
                           "play|" + quote_plus(item["path"]) + "|" + quote_plus(src) + "|" + quote_plus(label) + "|" + quote_plus(art) + "|" + quote_plus(plot),
                           False, context=ctx, art=art, plot=plot, playable=True)
    end_dir(sort=True)


def open_settings():
    ADDON.openSettings()


def show_root():
    xbmcplugin.setPluginCategory(HANDLE, ADDON_NAME)
    xbmcplugin.setContent(HANDLE, "videos")
    installed = sum(1 for meta in SOURCES.values() if has_addon(meta["id"]))
    fav_count = len(load_favs())
    history_count = len(load_history())
    add_directory_item("[B]Startseite[/B]  [COLOR gray]Hub & Schnellzugriff[/COLOR]", "hub", True, art=ICON,
                       plot="Dein Hub mit Status, Entdecken, Sendern und Schnellzugriffen.")
    add_directory_item("[B]Entdecken[/B]  [COLOR gray]Sender direkt öffnen[/COLOR]", "discover", True, art=ICON,
                       plot="Schneller Zugriff auf installierte oder verfügbare Quellen.")
    add_directory_item("[B]Meine Mediathek[/B]  [COLOR gray]Favoriten & Verlauf[/COLOR]", "library", True, art="resources/media/favorites.jpg",
                       plot="Alles, was du gespeichert oder zuletzt geöffnet hast.")
    add_directory_item("[B]Werkzeuge[/B]  [COLOR gray]Pflege & Einstellungen[/COLOR]", "tools", True, art="resources/media/refresh.jpg",
                       plot="Einstellungen, Repo, Index aktualisieren und Wartung.")

    status = "Quellen aktiv: %d/%d\nFavoriten: %d\nVerlauf: %d\nQualität: %s" % (
        installed, len(SOURCES), fav_count, history_count, quality_label()
    )
    add_directory_item("[B]Status[/B]  [COLOR gray]%d/%d aktiv[/COLOR]" % (installed, len(SOURCES)),
                       "status", True, art=ICON, plot=status)
    end_dir()


def show_hub():
    xbmcplugin.setPluginCategory(HANDLE, "Startseite")
    xbmcplugin.setContent(HANDLE, "videos")
    installed = [s for s, meta in SOURCES.items() if has_addon(meta["id"])]
    missing = [s for s, meta in SOURCES.items() if not has_addon(meta["id"])]

    add_directory_item("[B]Jetzt weitermachen[/B]", "library", True, art="resources/media/favorites.jpg",
                       plot="Favoriten, zuletzt geöffnete Inhalte und schnelle Rücksprünge.")
    add_directory_item("[B]Entdecken[/B]", "discover", True, art=ICON,
                       plot="Installierte Sender zuerst, fehlende danach.")
    add_directory_item("[B]Werkzeuge[/B]", "tools", True, art="resources/media/refresh.jpg",
                       plot="Wartung, Einstellungen und Repository.")

    for src in installed:
        meta = SOURCES[src]
        add_directory_item("[B]%s[/B]  [COLOR lime]bereit[/COLOR]" % src,
                           "browse|" + quote_plus(src) + "|" + quote_plus(meta["path"]),
                           True, art=meta["art"], plot=meta["desc"])
    for src in missing:
        meta = SOURCES[src]
        plot = meta["desc"] + "\n\nQuelle ist noch nicht installiert."
        add_directory_item("[B]%s[/B]  [COLOR red]nicht installiert[/COLOR]" % src,
                           "browse|" + quote_plus(src) + "|" + quote_plus(meta["path"]),
                           True, art=meta["art"], plot=plot)
    end_dir()


def show_status():
    xbmcplugin.setPluginCategory(HANDLE, "Status")
    xbmcplugin.setContent(HANDLE, "videos")
    favs = len(load_favs())
    hist = len(load_history())
    installed = sum(1 for meta in SOURCES.values() if has_addon(meta["id"]))
    add_directory_item("[B]Gesamtstatus[/B]  [COLOR gray]%d/%d Quellen aktiv[/COLOR]" % (installed, len(SOURCES)),
                       "noop", False, art=ICON,
                       plot="Favoriten: %d\nVerlauf: %d\nSuchverlauf: %d\nQualität: %s\n%s" % (
                           favs, hist, len(load_searches()), quality_label(), index_stats_text()
                       ))
    for src, meta in SOURCES.items():
        plot = "%s\nAddon-ID: %s\nPfad: %s" % (meta["desc"], meta["id"], meta["path"])
        add_directory_item("%s  %s" % (src, source_state(src)),
                           "browse|" + quote_plus(src) + "|" + quote_plus(meta["path"]),
                           True, art=meta["art"], plot=plot)
    end_dir()


def show_discover():
    xbmcplugin.setPluginCategory(HANDLE, "Entdecken")
    xbmcplugin.setContent(HANDLE, "videos")
    add_directory_item("[B]Alle Sender[/B]", "sources", True, art=ICON,
                       plot="Alle verfügbaren Quellen mit Status und Direktzugriff.")
    add_directory_item("[B]Installierte Sender zuerst[/B]", "readysources", True, art=ICON,
                       plot="Zeigt zuerst nutzbare Quellen.")
    end_dir()


def show_ready_sources():
    xbmcplugin.setPluginCategory(HANDLE, "Installierte Sender")
    xbmcplugin.setContent(HANDLE, "videos")
    installed = [(src, meta) for src, meta in SOURCES.items() if has_addon(meta["id"])]
    missing = [(src, meta) for src, meta in SOURCES.items() if not has_addon(meta["id"])]
    for src, meta in installed:
        add_directory_item("[B]%s[/B]  [COLOR lime]bereit[/COLOR]" % src,
                           "browse|" + quote_plus(src) + "|" + quote_plus(meta["path"]),
                           True, art=meta["art"], plot=meta["desc"])
    if missing:
        add_directory_item("[COLOR gray]Nicht installiert[/COLOR]", "noop", False, art=ICON,
                           plot="Diese Quellen sind aktuell nicht in Kodi verfügbar.")
        for src, meta in missing:
            add_directory_item("%s  [COLOR red]fehlt[/COLOR]" % src,
                               "browse|" + quote_plus(src) + "|" + quote_plus(meta["path"]),
                               True, art=meta["art"], plot=meta["desc"])
    end_dir()


def show_sources():
    xbmcplugin.setPluginCategory(HANDLE, "Sender")
    xbmcplugin.setContent(HANDLE, "videos")
    for src, meta in SOURCES.items():
        plot = "%s\nStatus: %s" % (
            meta["desc"], "Installiert" if has_addon(meta["id"]) else "Nicht installiert"
        )
        add_directory_item("[B]%s[/B] %s" % (src, "[COLOR lime]✓[/COLOR]" if has_addon(meta["id"]) else "[COLOR red]✗[/COLOR]"),
                           "browse|" + quote_plus(src) + "|" + quote_plus(meta["path"]),
                           True, art=meta["art"], plot=plot)
    end_dir()


def show_library():
    xbmcplugin.setPluginCategory(HANDLE, "Meine Mediathek")
    xbmcplugin.setContent(HANDLE, "videos")
    add_directory_item("[B]Favoriten[/B]  [COLOR gray](%d)[/COLOR]" % len(load_favs()),
                       "favorites", True, art="resources/media/favorites.jpg",
                       plot="Deine gespeicherten Einträge.")
    add_directory_item("[B]Zuletzt geöffnet[/B]  [COLOR gray](%d)[/COLOR]" % len(load_history()),
                       "history", True, art=ICON,
                       plot="Zuletzt geöffnete Ordner und abgespielte Inhalte.")
    end_dir()


def show_tools():
    xbmcplugin.setPluginCategory(HANDLE, "Werkzeuge")
    xbmcplugin.setContent(HANDLE, "videos")
    add_directory_item("[B]Ansicht aktualisieren[/B]", "refresh", False, art="resources/media/refresh.jpg",
                       plot="Aktualisiert die aktuelle Kodi-Ansicht.")
    add_directory_item("[B]Einstellungen öffnen[/B]", "settings", False, art=ICON,
                       plot="Öffnet die Addon-Einstellungen.")
    add_directory_item("[B]Kodinerds Repo installieren / aktualisieren[/B]", "installrepo", False, art=ICON,
                       plot="Installiert oder aktualisiert das benötigte Repository.")
    add_directory_item("[B]Verlauf leeren[/B]", "clearhistory", False, art=ICON,
                       plot="Entfernt alle zuletzt geöffneten Einträge.")
    end_dir()


def show_favorites():
    xbmcplugin.setPluginCategory(HANDLE, "Favoriten")
    xbmcplugin.setContent(HANDLE, "videos")
    favs = sorted(load_favs(), key=lambda x: x.get("added", 0), reverse=True)
    if not favs:
        add_directory_item("Keine Favoriten gespeichert", "noop", False, art="resources/media/favorites.jpg",
                           plot="Füge über das Kontextmenü Einträge zu deinen Favoriten hinzu.")
        end_dir()
        return
    for f in favs:
        label = f.get("label", "")
        art = f.get("art", "") or art_for_source(f.get("source", ""))
        plot = f.get("plot", "")
        src = f.get("source", "")
        ctx = [("Aus Favoriten entfernen", "RunPlugin(%s)" % mkurl({"action": "removefav", "path": f["path"]}))]
        display = "[COLOR gold]★[/COLOR] %s [COLOR gray](%s)[/COLOR]" % (label, src)
        if f.get("folder"):
            add_directory_item(display, "browse|" + quote_plus(src) + "|" + quote_plus(f["path"]),
                               True, context=ctx, art=art, plot=plot)
        else:
            add_directory_item(display, "play|" + quote_plus(f["path"]) + "|" + quote_plus(src) + "|" + quote_plus(label) + "|" + quote_plus(art) + "|" + quote_plus(plot),
                               False, context=ctx, art=art, plot=plot, playable=True)
    end_dir(sort=True)


def show_history():
    xbmcplugin.setPluginCategory(HANDLE, "Zuletzt geöffnet")
    xbmcplugin.setContent(HANDLE, "videos")
    items = load_history()
    if not items:
        add_directory_item("Noch kein Verlauf vorhanden", "noop", False, art=ICON,
                           plot="Sobald du Sender, Ordner oder Videos öffnest, erscheinen sie hier.")
        end_dir()
        return
    for item in items:
        label = item.get("label", "")
        art = item.get("art", "") or art_for_source(item.get("source", ""))
        plot = item.get("plot", "")
        src = item.get("source", "")
        stamp = time.strftime("%d.%m.%Y %H:%M", time.localtime(item.get("added", 0)))
        display = "%s [COLOR gray](%s · %s)[/COLOR]" % (label, src, stamp)
        if item.get("folder"):
            add_directory_item(display, "browse|" + quote_plus(src) + "|" + quote_plus(item["path"]), True, art=art, plot=plot)
        else:
            add_directory_item(display, "play|" + quote_plus(item["path"]) + "|" + quote_plus(src) + "|" + quote_plus(label) + "|" + quote_plus(art) + "|" + quote_plus(plot),
                               False, art=art, plot=plot, playable=True)
    end_dir(sort=True)


def show_search_menu():
    notify("Suche wurde entfernt")
    show_root()


def browse(src, path):
    ensure_repo()
    xbmcplugin.setPluginCategory(HANDLE, src)
    xbmcplugin.setContent(HANDLE, "videos")
    if not has_addon(SOURCES.get(src, {}).get("id", "")):
        notify("%s ist noch nicht installiert" % src, xbmcgui.NOTIFICATION_WARNING)
    items = get_dir(path)
    add_history(src, src if path == SOURCES.get(src, {}).get("path") else path, path, True, art_for_source(src), "Geöffneter Ordner")
    if not items:
        add_directory_item("Keine Einträge gefunden", "noop", False, art=art_for_source(src),
                           plot="Die Quelle liefert aktuell keine Inhalte oder ist nicht erreichbar.")
        end_dir()
        return
    for it in items:
        label = it.get("label") or it.get("title") or ""
        p = it.get("file", "")
        typ = it.get("filetype", "file")
        art = ""
        if isinstance(it.get("art"), dict):
            art = it["art"].get("poster") or it["art"].get("thumb") or it["art"].get("icon") or ""
        art = art or it.get("thumbnail", "") or art_for_source(src)
        plot = it.get("plot", "")
        if typ == "directory":
            if is_fav(p):
                ctx = [("Aus Favoriten entfernen", "RunPlugin(%s)" % mkurl({"action": "removefav", "path": p}))]
            else:
                ctx = [("Zu Favoriten hinzufügen", "RunPlugin(%s)" % mkurl({
                    "action": "addfav", "src": src, "label": label, "path": p, "folder": "1", "art": art, "plot": plot,
                }))]
            add_directory_item(label, "browse|" + quote_plus(src) + "|" + quote_plus(p), True, ctx, art, plot)
        else:
            if is_fav(p):
                ctx = [("Aus Favoriten entfernen", "RunPlugin(%s)" % mkurl({"action": "removefav", "path": p}))]
                prefix = "[COLOR gold]★[/COLOR] "
            else:
                ctx = [("Zu Favoriten hinzufügen", "RunPlugin(%s)" % mkurl({
                    "action": "addfav", "src": src, "label": label, "path": p, "folder": "0", "art": art, "plot": plot,
                }))]
                prefix = ""
            add_directory_item(prefix + label,
                               "play|" + quote_plus(p) + "|" + quote_plus(src) + "|" + quote_plus(label) + "|" + quote_plus(art) + "|" + quote_plus(plot),
                               False, ctx, art, plot, playable=True)
    end_dir()


def play(p, src="", label="", art="", plot=""):
    if label or src:
        add_history(src, label or p, p, False, art or art_for_source(src), plot)
    li = xbmcgui.ListItem(path=p)
    set_art(li, art or art_for_source(src))
    try:
        li.setInfo("video", {"title": label or p, "plot": plot, "mediatype": "episode"})
    except Exception:
        pass
    li.setProperty("IsPlayable", "true")
    try:
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
    except Exception as e:
        log("setResolvedUrl failed for %s: %s" % (p, e), xbmc.LOGERROR)
        xbmc.Player().play(p, li)


def refresh():
    xbmc.executebuiltin("Container.Refresh")
    notify("Ansicht aktualisiert")


def clear_index():
    save_index_payload({"version": INDEX_VERSION, "updated": 0, "items": [], "stats": {"per_source": {}, "dirs": {}}})
    notify("Index gelöscht")


params = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
act = params.get("action", "")

if act == "hub":
    show_hub()
elif act == "status":
    show_status()
elif act == "discover":
    show_discover()
elif act == "readysources":
    show_ready_sources()
elif act == "sources":
    show_sources()
elif act == "library":
    show_library()
elif act == "favorites":
    show_favorites()
elif act == "history":
    show_history()
elif act == "tools":
    show_tools()
elif act == "settings":
    open_settings()
elif act == "refresh":
    refresh()
elif act == "addfav":
    add_fav(params.get("src"), params.get("label"), params.get("path"), params.get("folder") == "1", params.get("art", ""), params.get("plot", ""))
    xbmc.executebuiltin("Container.Refresh")
elif act == "removefav":
    remove_fav(params.get("path"))
    xbmc.executebuiltin("Container.Refresh")
elif act == "clearhistory":
    clear_history()
    xbmc.executebuiltin("Container.Refresh")
elif act in ("searchmenu", "search", "buildindex", "clearindex", "clearsearches") or act.startswith("dosearch|"):
    notify("Suche wurde entfernt")
    show_root()
elif act.startswith("browse|"):
    _, s, p = act.split("|", 2)
    browse(unquote_plus(s), unquote_plus(p))
elif act.startswith("play|"):
    parts = act.split("|")
    p = unquote_plus(parts[1]) if len(parts) > 1 else ""
    src = unquote_plus(parts[2]) if len(parts) > 2 else ""
    label = unquote_plus(parts[3]) if len(parts) > 3 else ""
    art = unquote_plus(parts[4]) if len(parts) > 4 else ""
    plot = unquote_plus(parts[5]) if len(parts) > 5 else ""
    play(p, src, label, art, plot)
elif act == "installrepo":
    install_repo()
else:
    show_root()
