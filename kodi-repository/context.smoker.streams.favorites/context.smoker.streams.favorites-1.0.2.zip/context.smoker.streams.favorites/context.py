# -*- coding: utf-8 -*-
import sys
import urllib.parse
import xbmc
import xbmcgui

TARGET = 'plugin://plugin.video.smoker.streams.favorites/?action=add'


def _get_label():
    for key in (
        'ListItem.Label',
        'Container.ListItem.Label',
    ):
        value = xbmc.getInfoLabel(key)
        if value:
            return value
    return 'Unbekannter Eintrag'


def _get_thumb():
    for key in (
        'ListItem.Art(thumb)',
        'ListItem.Thumb',
        'ListItem.Icon',
        'Container.ListItem.Art(thumb)',
    ):
        value = xbmc.getInfoLabel(key)
        if value:
            return value
    return ''


def _get_fanart():
    for key in (
        'ListItem.Art(fanart)',
        'Container.ListItem.Art(fanart)',
    ):
        value = xbmc.getInfoLabel(key)
        if value:
            return value
    return ''


def _get_path():
    candidates = [
        'ListItem.FileNameAndPath',
        'ListItem.Path',
        'Container.ListItem.FileNameAndPath',
        'Container.ListItem.Path',
    ]
    for key in candidates:
        value = xbmc.getInfoLabel(key)
        if value:
            return value
    return ''


def _get_source():
    for key in ('Container.FolderName', 'Container.PluginName'):
        value = xbmc.getInfoLabel(key)
        if value:
            return value
    return 'Video-Addons'


def main():
    name = _get_label().strip()
    path = _get_path().strip()
    thumb = _get_thumb().strip()
    fanart = _get_fanart().strip()
    source = _get_source().strip()

    if not path:
        xbmcgui.Dialog().notification(
            'Smoker Streams Favoriten',
            'Kein gültiger Pfad für diesen Eintrag gefunden.',
            xbmcgui.NOTIFICATION_ERROR,
            4000
        )
        return

    params = {
        'name': name,
        'path': path,
        'thumb': thumb,
        'fanart': fanart,
        'source': source,
    }
    url = TARGET + '&' + urllib.parse.urlencode(params)
    xbmc.executebuiltin('RunPlugin(%s)' % url)


if __name__ == '__main__':
    main()
