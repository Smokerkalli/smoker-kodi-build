# -*- coding: utf-8 -*-
"""Read descriptions from SerienStream detail pages."""
from html.parser import HTMLParser


class _DescriptionParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self.meta = {}
        self.target = None
        self.depth = 0
        self.finished = False

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'meta':
            key = (attrs.get('name') or attrs.get('property') or attrs.get('itemprop') or '').lower()
            if key in ('description', 'og:description'):
                self.meta[key] = attrs.get('content', '').strip()
            return
        if self.depth:
            if tag == self.target:
                self.depth += 1
            if tag == 'br':
                self.parts.append('\n')
        elif not self.finished and (
                'description-text' in attrs.get('class', '').split()
                or attrs.get('itemprop') == 'description'):
            self.target = tag
            self.depth = 1

    def handle_endtag(self, tag):
        if self.depth and tag == self.target:
            self.depth -= 1
            if not self.depth:
                self.finished = bool(''.join(self.parts).strip())

    def handle_data(self, data):
        if self.depth:
            self.parts.append(data)


def extract_description(html):
    parser = _DescriptionParser()
    parser.feed(html or '')
    parser.close()
    description = ''.join(parser.parts).strip()
    if description:
        return '\n'.join(' '.join(line.split()) for line in description.splitlines()).strip()
    return parser.meta.get('og:description') or parser.meta.get('description', '')


def load_description(url):
    if not url:
        return ''
    from resources.lib.handler.requestHandler import cRequestHandler
    request = cRequestHandler(url, caching=True, ignoreErrors=True)
    request.cacheTime = 86400
    return extract_description(request.request())
