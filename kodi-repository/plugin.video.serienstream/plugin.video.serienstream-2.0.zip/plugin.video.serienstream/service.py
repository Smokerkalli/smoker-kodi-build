# -*- coding: utf-8 -*-
"""Startup maintenance for the SerienStream-only edition."""
import time
from resources.lib.config import cConfig
from resources.lib.handler.pluginHandler import cPluginHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import cCache


def main():
    config = cConfig()
    status_key = config.getAddonInfo('id') + '_main'
    cCache().set(status_key, 'running')
    try:
        cPluginHandler().checkDomain()
        cPluginHandler().getAvailablePlugins()
        current_time = int(time.time())
        cache_age = int(config.getSetting('cacheDeltaDay', 2)) * 86400
        if current_time >= int(config.getSetting('lastdelhtml', 0)) + cache_age:
            cRequestHandler('').clearCache()
            config.setSetting('lastdelhtml', str(current_time))
    finally:
        cCache().set(status_key, 'finished')


if __name__ == '__main__':
    main()
